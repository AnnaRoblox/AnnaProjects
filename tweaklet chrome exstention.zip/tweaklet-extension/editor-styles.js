/* Kept in a constructed stylesheet so page CSS and most site CSPs can't break the editor. */
globalThis.__TWEAKLET_EDITOR_CSS = String.raw`
:host {
  --twk-ink: #242335;
  --twk-muted: #858493;
  --twk-purple: #6851ea;
  --twk-line: #edeaf2;
  --twk-bg: #fff;
  color-scheme: light;
  font: 12px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}
*, *::before, *::after { box-sizing: border-box; }
[hidden] { display: none !important; }
button, input, select { font: inherit; }
button { cursor: pointer; }
button:focus-visible, input:focus-visible, select:focus-visible { outline: 2px solid #806df2; outline-offset: 2px; }
#twk-panel {
  position: fixed; z-index: 3; top: 16px; right: 16px;
  width: min(354px, calc(100vw - 24px)); max-height: calc(100vh - 32px);
  overflow: auto; overscroll-behavior: contain; pointer-events: auto;
  border: 1px solid #e7e4ee; border-radius: 17px; background: var(--twk-bg);
  color: var(--twk-ink); box-shadow: 0 20px 75px rgba(25,20,61,.22), 0 3px 10px rgba(25,20,61,.08);
}
#twk-panel::-webkit-scrollbar, .twk-saved-list::-webkit-scrollbar { width: 6px; }
#twk-panel::-webkit-scrollbar-thumb, .twk-saved-list::-webkit-scrollbar-thumb { background: #dfdce8; border-radius: 6px; }
.twk-topbar { position: sticky; z-index: 2; top: 0; display: flex; align-items: center; gap: 9px; padding: 13px 15px; border-bottom: 1px solid var(--twk-line); background: rgba(255,255,255,.97); backdrop-filter: blur(12px); }
.twk-logo { display: grid; place-items: center; flex: none; width: 29px; height: 29px; border-radius: 9px; background: var(--twk-purple); color: #fff; }
.twk-logo svg { width: 19px; height: 19px; }
.twk-brand { display: flex; flex-direction: column; flex: 1; min-width: 0; line-height: 1.1; }
.twk-brand strong { font-size: 13px; letter-spacing: -.3px; }
.twk-brand span { margin-top: 3px; color: #8b8996; font-size: 9px; font-weight: 730; letter-spacing: .75px; }
.twk-close, .twk-icon-button { display: grid; place-items: center; flex: none; border: 0; background: transparent; color: #92909e; }
.twk-close { width: 27px; height: 27px; border-radius: 8px; }
.twk-close:hover, .twk-icon-button:hover { background: #f5f3fa; color: #4938ae; }
.twk-close svg, .twk-icon-button svg { width: 16px; height: 16px; }
.twk-content { padding: 16px; }
.twk-context { display: flex; align-items: center; gap: 7px; margin-bottom: 14px; color: #817d91; font-size: 10px; }
.twk-context .twk-live-dot { width: 6px; height: 6px; border-radius: 50%; background: #40b993; box-shadow: 0 0 0 3px #e3f7ef; }
.twk-context strong { min-width: 0; overflow: hidden; max-width: 205px; color: #524f67; font-weight: 700; text-overflow: ellipsis; white-space: nowrap; }
.twk-context .twk-context-suffix { margin-left: auto; font-size: 9px; color: #aaa7b3; white-space: nowrap; }
.twk-empty { padding: 24px 16px 19px; border: 1px dashed #dcd7f3; border-radius: 13px; background: #fbfaff; text-align: center; }
.twk-empty-graphic { display: grid; place-items: center; width: 49px; height: 49px; margin: 0 auto 12px; border: 1px solid #ded6fa; border-radius: 15px; background: #f0eaff; color: var(--twk-purple); box-shadow: 0 0 0 6px rgba(112,81,235,.05); }
.twk-empty-graphic svg { width: 26px; height: 26px; }
.twk-empty h2 { margin: 0 0 5px; font-size: 14px; font-weight: 760; letter-spacing: -.2px; }
.twk-empty p { margin: 0 auto 13px; max-width: 230px; color: #82808f; font-size: 11px; line-height: 1.55; }
.twk-pick-button { padding: 8px 11px; border: 1px solid #d7cef9; border-radius: 8px; background: #fff; color: #5f49d5; font-size: 10.5px; font-weight: 740; }
.twk-pick-button:hover:not(:disabled) { border-color: #977ff8; background: #f6f2ff; }
.twk-pick-button:disabled { cursor: default; opacity: .7; }
.twk-empty-manual { display: block; margin: 10px auto 0; border: 0; padding: 2px; background: none; color: #7058dd; font-size: 10px; font-weight: 720; }
.twk-empty-manual:hover { text-decoration: underline; }
.twk-target { display: flex; align-items: center; gap: 8px; padding: 11px 12px; border: 1px solid #e9e5f5; border-radius: 11px; background: #faf9ff; }
.twk-target-icon { display: grid; place-items: center; flex: none; width: 29px; height: 29px; border-radius: 8px; background: #ede8ff; color: #6951e8; }
.twk-target-icon svg { width: 16px; height: 16px; }
.twk-target-copy { display: flex; flex: 1; flex-direction: column; min-width: 0; }
.twk-target-copy small { color: #908ca0; font-size: 9px; font-weight: 730; letter-spacing: .75px; }
.twk-target-copy strong { overflow: hidden; font-size: 11.5px; font-weight: 750; text-overflow: ellipsis; white-space: nowrap; }
.twk-change-target { flex: none; padding: 5px 7px; border: 1px solid #dcd5f6; border-radius: 7px; background: #fff; color: #6a54d9; font-size: 10px; font-weight: 700; }
.twk-change-target:hover { background: #f2edff; }
.twk-selector { overflow: hidden; margin: 7px 3px 12px; color: #a4a1b0; font: 9.5px/1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; text-overflow: ellipsis; white-space: nowrap; }
.twk-section { margin: 0 0 18px; }
.twk-targeting { border: 1px solid #e9e5f6; border-radius: 11px; padding: 11px 12px; background: #fdfcff; }
.twk-targeting .twk-section-header { margin-bottom: 8px; }
.twk-match-pill { border-radius: 5px; padding: 3px 6px; background: #f0ecff; color: #6651d6 !important; font-size: 9px !important; font-weight: 750; }
.twk-specificity { display: block; width: 100%; height: 17px; margin: 2px 0 3px; accent-color: #6952e7; cursor: pointer; }
.twk-specificity:disabled { opacity: .5; cursor: not-allowed; }
.twk-scale { display: flex; justify-content: space-between; gap: 2px; color: #9995a6; font-size: 9px; }
.twk-scale > span { white-space: nowrap; }
.twk-scale > span.active { color: #6652d7; font-weight: 790; }
.twk-targeting-note { margin: 10px 0 0; color: #777285; font-size: 10px; }
.twk-class-filter { display: flex; align-items: center; gap: 6px; margin-top: 10px; color: #625d75; cursor: pointer; font-size: 10px; }
.twk-class-filter input { width: 13px; height: 13px; margin: 0; accent-color: #6851ea; }
.twk-class-filter code { border: 1px solid #e9e3fa; border-radius: 4px; padding: 1px 4px; background: #f5f1ff; color: #6851cc; font: 9px ui-monospace, SFMono-Regular, Consolas, monospace; }
.twk-manual-toggle { display: block; margin: 10px 0 0; padding: 2px 0; border: 0; background: none; color: #6851d7; text-align: left; font-size: 10px; font-weight: 720; }
.twk-manual-toggle:hover { text-decoration: underline; }
.twk-manual-controls { margin-top: 8px; }
.twk-manual-row { display: flex; gap: 5px; }
.twk-manual-row input { flex: 1; min-width: 0; height: 32px; border: 1px solid #ded9ef; border-radius: 7px; outline: 0; padding: 0 7px; background: white; color: #38334e; font: 10px ui-monospace, SFMono-Regular, Consolas, monospace; }
.twk-manual-row input:focus { border-color: #9580ee; }
.twk-manual-row input[aria-invalid="true"] { border-color: #dc8095; }
.twk-manual-row button { flex: none; border: 1px solid #6d56e9; border-radius: 7px; padding: 0 10px; background: #6c55ea; color: #fff; font-size: 10px; font-weight: 740; }
.twk-manual-row button:hover { background: #5840d6; }
.twk-manual-feedback { margin: 5px 0 0; color: #9d98ac; font-size: 9px; line-height: 1.35; }
.twk-manual-feedback[data-error="true"] { color: #c14c68; }
.twk-section-header { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 9px; }
.twk-section-header h3 { margin: 0; color: #343245; font-size: 10px; font-weight: 830; letter-spacing: .85px; }
.twk-section-header span { color: #a09dab; font-size: 9.5px; }
.twk-coords { display: flex; align-items: center; gap: 8px; }
.twk-coordinate { display: flex; align-items: center; flex: 1; min-width: 0; height: 35px; border: 1px solid #e5e3eb; border-radius: 8px; background: #fff; }
.twk-coordinate:focus-within { border-color: #a996f3; }
.twk-coordinate label { padding-left: 10px; color: #7460df; font-size: 10px; font-weight: 820; }
.twk-coordinate input { width: 100%; min-width: 0; border: 0; outline: 0; padding: 4px 6px; background: transparent; color: #343346; font-size: 12px; font-weight: 650; appearance: textfield; }
.twk-coordinate input::-webkit-outer-spin-button, .twk-coordinate input::-webkit-inner-spin-button { margin: 0; -webkit-appearance: none; }
.twk-coordinate .twk-px { padding-right: 9px; color: #adaab6; font-size: 10px; }
.twk-reset { flex: none; height: 35px; padding: 0 9px; border: 1px solid #e5e3eb; border-radius: 8px; background: #fff; color: #797587; font-size: 10px; font-weight: 650; }
.twk-reset:hover { background: #f8f6fe; color: #634be0; }
.twk-help { margin: 7px 0 0; color: #a09dab; font-size: 10px; }
.twk-property-list { display: flex; flex-direction: column; gap: 8px; }
.twk-no-properties { padding: 10px 11px; border: 1px dashed #e4e1eb; border-radius: 8px; color: #aaa7b1; font-size: 10.5px; }
.twk-property-block { min-width: 0; }
.twk-property-row { display: flex; align-items: center; gap: 5px; }
.twk-color-picker { flex: 0 0 31px; width: 31px; height: 30px; border: 1px solid #e1ddec; border-radius: 7px; padding: 2px; background: #fff; cursor: pointer; }
.twk-color-picker::-webkit-color-swatch-wrapper { padding: 0; }
.twk-color-picker::-webkit-color-swatch { border: 0; border-radius: 4px; }
.twk-range-row { display: flex; align-items: center; gap: 7px; margin: 5px 32px 0 96px; color: #aaa6b4; font-size: 9px; }
.twk-range-row input { flex: 1; min-width: 0; height: 12px; margin: 0; accent-color: #725bf0; cursor: pointer; }
.twk-property-name { display: flex; flex-direction: column; flex: 0 0 91px; min-width: 0; }
.twk-property-name strong { overflow: hidden; font-size: 10px; font-weight: 690; text-overflow: ellipsis; white-space: nowrap; }
.twk-property-name small { overflow: hidden; color: #a5a2ae; font: 8.5px ui-monospace, SFMono-Regular, Consolas, monospace; text-overflow: ellipsis; white-space: nowrap; }
.twk-value-input { width: 100%; min-width: 0; height: 33px; border: 1px solid #e5e3eb; border-radius: 8px; padding: 0 8px; outline: 0; background: #fff; color: #393649; font-size: 10.5px; }
.twk-value-input:focus { border-color: #a996f3; }
.twk-value-input[aria-invalid="true"] { border-color: #dc8095; background: #fff9fa; }
.twk-icon-button { width: 27px; height: 30px; border-radius: 7px; }
.twk-add-row { display: flex; gap: 6px; margin-top: 9px; }
.twk-preset, .twk-custom-name { min-width: 0; height: 33px; border: 1px solid #e5e3eb; border-radius: 8px; padding: 0 7px; outline: 0; background: #fff; color: #625f70; font-size: 10px; }
.twk-preset { flex: 1; }
.twk-custom-name { width: 100%; margin-top: 7px; }
.twk-add-button { flex: none; height: 33px; padding: 0 9px; border: 1px solid #d8cff9; border-radius: 8px; background: #f8f5ff; color: #6650df; font-size: 10px; font-weight: 750; }
.twk-add-button:hover { border-color: #b3a2f5; background: #f1ebff; }
.twk-scope { margin: 0; }
.twk-segments { display: flex; padding: 3px; border: 1px solid #eceaf0; border-radius: 9px; background: #f6f5f8; }
.twk-segments button { flex: 1; padding: 7px 4px; border: 0; border-radius: 6px; background: transparent; color: #898693; font-size: 10px; font-weight: 700; }
.twk-segments button[aria-pressed="true"] { background: #fff; color: #5642ca; box-shadow: 0 1px 4px rgba(37,28,73,.1); }
.twk-section-controls { margin-top: 9px; }
.twk-section-controls label { display: block; margin-bottom: 4px; color: #706d7f; font-size: 10px; font-weight: 700; }
.twk-section-controls input { width: 100%; height: 33px; border: 1px solid #e5e0ed; border-radius: 7px; outline: 0; padding: 0 8px; background: white; color: #373148; font: 10.5px ui-monospace, SFMono-Regular, Consolas, monospace; }
.twk-section-controls input:focus { border-color: #a996f3; }
.twk-section-controls input[aria-invalid="true"] { border-color: #dc8095; }
.twk-section-controls small { display: block; margin-top: 5px; color: #a09dab; font-size: 9px; line-height: 1.4; }
.twk-scope-note { overflow: hidden; margin: 7px 1px 0; color: #a09dab; font-size: 9.5px; text-overflow: ellipsis; white-space: nowrap; }
.twk-saved { border-top: 1px solid var(--twk-line); padding: 14px 16px 12px; }
.twk-saved-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.twk-saved-head strong { font-size: 11px; font-weight: 770; }
.twk-count { display: grid; place-items: center; min-width: 20px; height: 19px; padding: 0 5px; border-radius: 5px; background: #f1eff7; color: #746b9b; font-size: 9px; font-weight: 750; }
.twk-saved-list { max-height: 152px; overflow-y: auto; }
.twk-saved-empty { padding: 9px 0 4px; color: #a7a4b1; font-size: 10.5px; }
.twk-saved-item { display: flex; align-items: center; gap: 4px; padding: 3px 0; border-bottom: 1px solid #f3f2f5; }
.twk-saved-item:last-child { border-bottom: 0; }
.twk-saved-pick { display: flex; align-items: center; flex: 1; gap: 7px; min-width: 0; padding: 4px 2px; border: 0; border-radius: 5px; background: none; color: #474453; text-align: left; }
.twk-saved-pick:hover:not(:disabled) { color: #634cdf; }
.twk-saved-pick:disabled { opacity: .55; cursor: default; }
.twk-saved-pick strong { overflow: hidden; flex: 1; font-size: 10px; font-weight: 650; text-overflow: ellipsis; white-space: nowrap; }
.twk-scope-badge { flex: none; border-radius: 4px; padding: 2px 4px; background: #f1effa; color: #7666c7; font-size: 8px; font-weight: 760; }
.twk-footer { position: sticky; z-index: 2; bottom: 0; display: flex; align-items: center; gap: 6px; min-height: 39px; border-top: 1px solid var(--twk-line); padding: 0 16px; background: #fbfafc; color: #918e9d; font-size: 10px; }
.twk-status-dot { width: 6px; height: 6px; border-radius: 50%; background: #34b88d; }
.twk-footer[data-kind="saving"] .twk-status-dot { background: #e8ae52; }
.twk-footer[data-kind="error"] .twk-status-dot { background: #df617c; }
.twk-footer .twk-footer-privacy { margin-left: auto; color: #aaa7b2; font-size: 9px; }
#twk-group-outlines { position: fixed; z-index: 1; inset: 0; pointer-events: none; }
.twk-group-outline { position: fixed; border: 1px dashed rgba(113,86,245,.8); border-radius: 4px; background: rgba(114,86,245,.045); pointer-events: none; }
#twk-outline { position: fixed; z-index: 1; border: 2px solid #7156f5; border-radius: 4px; background: rgba(111,82,240,.08); box-shadow: 0 0 0 2px rgba(255,255,255,.8), 0 0 0 4px rgba(107,79,238,.3); pointer-events: none; }
#twk-outline[data-picking="true"] { border-color: #31b696; background: rgba(52,193,150,.10); box-shadow: 0 0 0 2px rgba(255,255,255,.85), 0 0 0 4px rgba(49,182,150,.3); }
.twk-outline-tag { position: absolute; top: -25px; left: -2px; max-width: 170px; border-radius: 5px 5px 0 0; padding: 3px 6px; background: #6b51ee; color: #fff; font-size: 9px; font-weight: 800; letter-spacing: .5px; white-space: nowrap; }
#twk-outline[data-picking="true"] .twk-outline-tag { background: #26ab86; }
#twk-outline[data-below="true"] .twk-outline-tag { top: auto; bottom: -24px; border-radius: 0 0 5px 5px; }
#twk-handle { position: fixed; z-index: 2; display: flex; align-items: center; gap: 6px; height: 27px; padding: 0 9px; border: 1px solid #fff; border-radius: 7px; background: #644bed; box-shadow: 0 4px 13px rgba(61,39,166,.3); color: #fff; pointer-events: auto; cursor: grab; font-size: 9px; font-weight: 800; letter-spacing: .4px; user-select: none; touch-action: none; }
#twk-handle svg { width: 14px; height: 14px; }
#twk-handle.dragging { cursor: grabbing; background: #4a31c7; }
#twk-toast { position: fixed; z-index: 4; bottom: 18px; left: 50%; transform: translateX(-50%); max-width: calc(100vw - 24px); border-radius: 9px; padding: 9px 12px; background: #28233d; box-shadow: 0 5px 18px #2019403b; color: #fff; font-size: 11px; font-weight: 600; pointer-events: none; }
@media (max-width: 430px) { #twk-panel { top: 10px; right: 10px; max-height: calc(100vh - 20px); } }
`;
