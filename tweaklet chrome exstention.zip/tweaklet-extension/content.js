(() => {
  "use strict";

  // A top-frame content script runs on every normal website so saved edits also run
  // when the popup isn't open. Nothing is sent to a server.
  if (window !== window.top || !/^https?:$/.test(location.protocol)) return;

  const SITE_KEY = `tweaklet:site:v1:${location.hostname.toLowerCase()}`;
  const INSTANCE_ID = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
  const PROPERTY_LABELS = {
    color: "Text color", "background-color": "Background", "font-size": "Font size",
    "font-weight": "Font weight", opacity: "Opacity", width: "Width", height: "Height",
    "border-radius": "Corner radius", "border-color": "Border color", "outline-color": "Outline color",
    fill: "SVG fill", stroke: "SVG stroke", display: "Display", padding: "Padding",
    margin: "Margin", border: "Border", "box-shadow": "Shadow", "z-index": "Layer"
  };
  const PROPERTY_EXAMPLES = {
    color: "#e94585", "background-color": "#f5f2ff", "font-size": "24px",
    "font-weight": "700", opacity: "0.5", width: "320px", height: "auto",
    "border-radius": "12px", "border-color": "#6851ea", "outline-color": "#6851ea",
    fill: "#6851ea", stroke: "#6851ea", display: "none", padding: "16px", margin: "8px",
    border: "1px solid red", "box-shadow": "0 4px 12px #0003", "z-index": "10"
  };
  const SCOPE_ORDER = { site: 0, section: 1, page: 2 };
  const MATCH_LABELS = ["Only this element", "Same-type siblings", "Same type in this area", "Every element of this type"];
  const ICONS = {
    cursor: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m4 2 5.6 17 3.1-6.3 6.2 3.4L4 2Z" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><path d="m17.7 17 2.8 4.6" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 5 19 19M19 5 5 19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    target: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="7.5" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="2.4" stroke="currentColor" stroke-width="1.8"/><path d="M12 1v3m0 16v3M1 12h3m16 0h3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    drag: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2v20M2 12h20M9 5l3-3 3 3M9 19l3 3 3-3M5 9l-3 3 3 3M19 9l3 3-3 3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 7h15M9 7V4.5h6V7m3.5 0-.8 13H6.3L5.5 7m4.5 4v6m4-6v6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  let site = { paused: false, rules: [], lastWriter: "" };
  let editorHost = null;
  let shadow = null;
  let picking = false;
  let hoveredElement = null;
  let selectedElement = null;
  let selectedRule = null;
  let manualOpen = false;
  let manualPreviewSelector = null;
  let swallowClickUntil = 0;
  let drag = null;
  let applyQueued = false;
  let overlayQueued = false;
  let saveTimer = null;
  let toastTimer = null;
  let urlTimer = null;
  let lastPath = location.pathname;
  let dirty = false;
  let pendingSaves = 0;
  let saveChain = Promise.resolve();

  // The first value of each overridden inline property is remembered, so pausing
  // or deleting an edit restores what the website had there before Tweaklet.
  const applied = new Map(); // Element -> Map(property -> { originalValue, originalPriority, appliedValue })
  const cssParser = document.createElement("div").style;

  function clampNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.max(-100000, Math.min(100000, Math.round(n * 10) / 10)) : 0;
  }

  function validPropertyName(name) {
    return /^--[a-zA-Z0-9_-]+$/.test(name) || /^-?[a-z][a-z0-9-]*$/.test(name);
  }

  function normalizeSite(raw) {
    const source = raw && typeof raw === "object" ? raw : {};
    const rules = Array.isArray(source.rules) ? source.rules : [];
    return {
      paused: source.paused === true,
      lastWriter: typeof source.lastWriter === "string" ? source.lastWriter : "",
      rules: rules.filter((rule) => rule && typeof rule.selector === "string" && rule.selector.length <= 1500)
        .map((rule) => {
          const props = Object.create(null);
          if (rule.props && typeof rule.props === "object" && !Array.isArray(rule.props)) {
            for (const [property, value] of Object.entries(rule.props)) {
              if (validPropertyName(property) && typeof value === "string") props[property] = value.slice(0, 2000);
            }
          }
          return {
            id: typeof rule.id === "string" ? rule.id : newId(),
            selector: rule.selector,
            label: typeof rule.label === "string" ? rule.label.slice(0, 100) : rule.selector.slice(0, 100),
            scope: ["site", "section", "page"].includes(rule.scope) ? rule.scope : "site",
            pathname: typeof rule.pathname === "string" ? rule.pathname : "/",
            sectionPath: normalizeSectionPath(rule.sectionPath) || defaultSectionPath(rule.pathname || "/"),
            matchLevel: rule.matchLevel === "custom" ? "custom" :
              Number.isInteger(rule.matchLevel) && rule.matchLevel >= 0 && rule.matchLevel <= 3 ? rule.matchLevel : 0,
            lastLevel: Number.isInteger(rule.lastLevel) && rule.lastLevel >= 0 && rule.lastLevel <= 3 ? rule.lastLevel : 0,
            anchorSelector: typeof rule.anchorSelector === "string" && rule.anchorSelector.length <= 1500
              ? rule.anchorSelector : rule.selector,
            classFilter: typeof rule.classFilter === "string" && stableClass(rule.classFilter) ? rule.classFilter : "",
            x: clampNumber(rule.x), y: clampNumber(rule.y), props,
            createdAt: Number(rule.createdAt) || Date.now(),
            updatedAt: Number(rule.updatedAt) || Date.now()
          };
        })
    };
  }

  function newId() {
    return globalThis.crypto?.randomUUID?.() || `edit-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  }

  function canonicalValue(property, rawValue) {
    if (typeof rawValue !== "string" || !rawValue.trim()) return null;
    try {
      if (!property.startsWith("--") && !CSS.supports(property, rawValue)) return null;
      cssParser.removeProperty(property);
      cssParser.setProperty(property, rawValue, "important");
      return cssParser.getPropertyValue(property) || null;
    } catch {
      return null;
    }
  }

  // A "section" is a URL path prefix, not a DNS subdomain: /watch matches
  // /watch and /watch/clip, but not /watchlist. Search and hash are ignored.
  function normalizeSectionPath(raw) {
    if (typeof raw !== "string") return null;
    const value = raw.trim();
    if (!value.startsWith("/") || /[?#\\]/.test(value) || value.length > 1000) return null;
    return value.replace(/\/+$/, "") || "/";
  }

  function defaultSectionPath(pathname) {
    const first = String(pathname || "/").split("/").filter(Boolean)[0];
    return first ? `/${first}` : "/";
  }

  function pathInSection(pathname, prefix) {
    return prefix === "/" || pathname === prefix || pathname.startsWith(`${prefix}/`);
  }

  function ruleIsHere(rule) {
    if (rule.scope === "site") return true;
    if (rule.scope === "section") return pathInSection(location.pathname, rule.sectionPath);
    return rule.pathname === location.pathname;
  }

  function safeFindAll(selector) {
    if (typeof selector !== "string" || !selector.trim()) return [];
    try {
      return Array.from(document.querySelectorAll(selector)).filter((element) =>
        element !== editorHost && !editorHost?.contains(element));
    } catch { return []; }
  }

  function safeFind(selector) {
    return safeFindAll(selector)[0] || null;
  }

  function selectorMatches(element, selector) {
    try { return element.matches(selector); } catch { return false; }
  }

  function updateAppliedElement(element, desired) {
    const previous = applied.get(element) || new Map();
    const style = element.style;
    if (!style) return;

    for (const [property, entry] of previous) {
      if (desired.has(property)) continue;
      // If the site changed this property since we last touched it, leave its
      // new value alone rather than replacing it with an out-of-date original.
      if (style.getPropertyValue(property) === entry.appliedValue &&
          style.getPropertyPriority(property) === "important") {
        if (entry.originalValue) style.setProperty(property, entry.originalValue, entry.originalPriority);
        else style.removeProperty(property);
      }
      previous.delete(property);
    }

    for (const [property, value] of desired) {
      let entry = previous.get(property);
      if (!entry) {
        entry = {
          originalValue: style.getPropertyValue(property),
          originalPriority: style.getPropertyPriority(property),
          appliedValue: value
        };
        previous.set(property, entry);
      }
      if (style.getPropertyValue(property) !== value || style.getPropertyPriority(property) !== "important") {
        style.setProperty(property, value, "important");
      }
      entry.appliedValue = value;
    }

    if (previous.size) applied.set(element, previous);
    else applied.delete(element);
  }

  function applyRules() {
    const desired = new Map();
    if (!site.paused) {
      // Broader rules run first; a page/section or an exact target can override
      // individual declarations on elements that also match a broad rule.
      const specificity = (rule) => rule.matchLevel === "custom" ? 1.5 : 3 - rule.matchLevel;
      const rules = site.rules.filter(ruleIsHere).sort((a, b) =>
        SCOPE_ORDER[a.scope] - SCOPE_ORDER[b.scope] || specificity(a) - specificity(b));
      for (const rule of rules) {
        const declarations = new Map();
        for (const [property, rawValue] of Object.entries(rule.props)) {
          const value = canonicalValue(property, rawValue);
          if (value !== null) declarations.set(property, value);
        }
        if (rule.x !== 0 || rule.y !== 0) {
          const offset = canonicalValue("translate", `${rule.x}px ${rule.y}px`);
          if (offset !== null) declarations.set("translate", offset);
        }
        if (!declarations.size) continue;
        for (const element of safeFindAll(rule.selector)) {
          const combined = desired.get(element) || new Map();
          for (const [property, value] of declarations) combined.set(property, value);
          desired.set(element, combined);
        }
      }
    }

    for (const element of applied.keys()) {
      updateAppliedElement(element, desired.get(element) || new Map());
      desired.delete(element);
    }
    for (const [element, declarations] of desired) updateAppliedElement(element, declarations);
    scheduleOverlay();
  }

  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    requestAnimationFrame(() => {
      applyQueued = false;
      applyRules();
    });
  }

  function updateSaveLabel(text, kind = "saved") {
    const footer = shadow?.getElementById("twk-footer");
    if (!footer) return;
    footer.dataset.kind = kind;
    shadow.getElementById("twk-status").textContent = text;
  }

  function queueSave() {
    dirty = true;
    updateSaveLabel("Saving changes…", "saving");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { void persistNow(); }, 260);
  }

  function persistNow() {
    clearTimeout(saveTimer);
    saveTimer = null;
    if (!dirty) return saveChain;
    dirty = false;
    pendingSaves++;
    site.lastWriter = INSTANCE_ID;
    const snapshot = JSON.parse(JSON.stringify(site));
    updateSaveLabel("Saving changes…", "saving");
    saveChain = saveChain.catch(() => {}).then(() => chrome.storage.local.set({ [SITE_KEY]: snapshot }))
      .then(() => {
        pendingSaves--;
        if (!dirty && pendingSaves === 0) updateSaveLabel("All changes saved", "saved");
      })
      .catch((error) => {
        pendingSaves--;
        dirty = true;
        updateSaveLabel("Could not save changes", "error");
        console.warn("Tweaklet could not save edits:", error);
      });
    return saveChain;
  }

  function updateUrlWatcher() {
    const needed = site.rules.some((rule) => rule.scope !== "site") || Boolean(editorHost);
    if (needed && !urlTimer) urlTimer = setInterval(checkPath, 800);
    else if (!needed && urlTimer) { clearInterval(urlTimer); urlTimer = null; }
  }

  function checkPath() {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    if (selectedRule && !ruleIsHere(selectedRule)) {
      selectedRule = null;
      selectedElement = null;
      manualPreviewSelector = null;
      picking = Boolean(editorHost);
      renderSelection();
    }
    applyRules();
    renderSavedList();
    scheduleOverlay();
  }

  function observePage() {
    const observer = new MutationObserver((mutations) => {
      if (!site.rules.length && !applied.size && !editorHost) return;
      const relevant = mutations.some((mutation) => {
        if (editorHost && (mutation.target === editorHost || editorHost.contains(mutation.target))) return false;
        if (mutation.type === "childList" && mutation.addedNodes.length === 1 &&
            mutation.addedNodes[0] === editorHost && !mutation.removedNodes.length) return false;
        return true;
      });
      if (!relevant) return;
      checkPath();
      scheduleApply();
      scheduleOverlay();
    });
    observer.observe(document, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ["style", "class", "id", "hidden", "name", "aria-label", "data-testid", "data-test", "data-cy", "data-qa"]
    });
    window.addEventListener("popstate", checkPath);
    window.addEventListener("pageshow", checkPath);
    window.addEventListener("pagehide", () => { if (dirty) void persistNow(); });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden" && dirty) void persistNow();
    });
  }

  function uniqueGlobally(selector, element) {
    try {
      const found = document.querySelectorAll(selector);
      return found.length === 1 && found[0] === element;
    } catch { return false; }
  }

  function stableId(value) {
    return value && value.length <= 64 && !/^(?:ember\d+|radix-|react-aria-|:r[0-9a-z]+:)/i.test(value) &&
      !/[a-f0-9]{14,}/i.test(value) && !/^\d+$/.test(value);
  }

  function stableClass(value) {
    return value.length < 44 && /^[a-zA-Z][\w-]*$/.test(value) &&
      !/^(?:css-|sc-|jsx-|_)/.test(value) && !/^[a-f0-9]{8,}$/i.test(value);
  }

  function uniqueAmongSiblings(element, selector) {
    const parent = element.parentElement;
    if (!parent) return false;
    try { return Array.from(parent.children).filter((child) => child.matches(selector)).length === 1; }
    catch { return false; }
  }

  function segmentFor(element) {
    const tag = element.localName.toLowerCase();
    if (element === document.documentElement) return { text: "html", anchor: true };
    if (element === document.body) return { text: "body", anchor: true };

    const id = element.getAttribute("id");
    if (stableId(id)) {
      const candidate = `#${CSS.escape(id)}`;
      if (uniqueGlobally(candidate, element)) return { text: candidate, anchor: true };
    }

    const attributes = ["data-testid", "data-test", "data-cy", "data-qa", "name", "aria-label"];
    for (const attribute of attributes) {
      const value = element.getAttribute(attribute);
      if (!value || value.length > 80 || /[\r\n]/.test(value)) continue;
      const candidate = `${tag}[${attribute}=${CSS.escape(value)}]`;
      if (uniqueGlobally(candidate, element)) return { text: candidate, anchor: true };
    }
    for (const attribute of attributes) {
      const value = element.getAttribute(attribute);
      if (!value || value.length > 80 || /[\r\n]/.test(value)) continue;
      const candidate = `${tag}[${attribute}=${CSS.escape(value)}]`;
      if (uniqueAmongSiblings(element, candidate)) return { text: candidate, anchor: false };
    }

    const classes = Array.from(element.classList || []).filter(stableClass).slice(0, 4);
    for (const name of classes) {
      const candidate = `${tag}.${CSS.escape(name)}`;
      if (uniqueAmongSiblings(element, candidate)) return { text: candidate, anchor: false };
    }

    const siblings = Array.from(element.parentElement?.children || []).filter((sibling) => sibling.localName === element.localName);
    if (siblings.length > 1) return { text: `${tag}:nth-of-type(${siblings.indexOf(element) + 1})`, anchor: false };
    return { text: tag, anchor: false };
  }

  function selectorFor(element) {
    const pieces = [];
    for (let current = element; current; current = current.parentElement) {
      const segment = segmentFor(current);
      pieces.unshift(segment.text);
      const selector = pieces.join(" > ");
      if (segment.anchor && uniqueGlobally(selector, element)) return selector;
      if (current === document.documentElement) break;
    }
    const selector = pieces.join(" > ");
    if (uniqueGlobally(selector, element)) return selector;

    // Last resort: an exact structural path, including positions for siblings.
    const fallback = [];
    for (let current = element; current; current = current.parentElement) {
      if (current === document.documentElement) { fallback.unshift("html"); break; }
      const tag = current.localName.toLowerCase();
      const siblings = Array.from(current.parentElement?.children || []).filter((sibling) => sibling.localName === current.localName);
      fallback.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${siblings.indexOf(current) + 1})` : tag);
    }
    return fallback.join(" > ");
  }

  function selectorAtLevel(element, level, classFilter = "") {
    const tag = element.localName.toLowerCase();
    const type = `${tag}${classFilter ? `.${CSS.escape(classFilter)}` : ""}`;
    if (level === 0) return selectorFor(element);
    if (level === 3) return type;
    const parent = element.parentElement;
    if (!parent) return type;
    if (level === 1) return `${selectorFor(parent)} > ${type}`;

    const landmarks = new Set(["main", "article", "section", "nav", "header", "footer", "aside", "form", "ul", "ol", "table"]);
    let area = parent.parentElement || parent;
    for (let ancestor = parent.parentElement; ancestor; ancestor = ancestor.parentElement) {
      if (landmarks.has(ancestor.localName.toLowerCase())) { area = ancestor; break; }
    }
    return `${selectorFor(area)} ${type}`;
  }

  function describeElement(element) {
    const tag = element.localName.toLowerCase();
    const id = element.getAttribute("id");
    if (stableId(id)) return `${tag}#${id}`.slice(0, 100);
    const name = Array.from(element.classList || []).find(stableClass);
    if (name) return `${tag}.${name}`.slice(0, 100);
    return `<${tag}>`;
  }

  function makeDraft(element) {
    const selector = selectorFor(element);
    return {
      id: newId(), selector, anchorSelector: selector, label: describeElement(element),
      scope: "site", pathname: location.pathname, sectionPath: defaultSectionPath(location.pathname),
      matchLevel: 0, lastLevel: 0, classFilter: "", x: 0, y: 0,
      props: Object.create(null), createdAt: Date.now(), updatedAt: Date.now()
    };
  }

  function hasChanges(rule) {
    return rule.x !== 0 || rule.y !== 0 || Object.values(rule.props).some((value) => value.trim() !== "");
  }

  function markChanged() {
    if (!selectedRule) return;
    if (!selectedRule.selector.trim()) {
      updateSaveLabel("Apply a CSS selector first", "error");
      return;
    }
    const saved = site.rules.some((rule) => rule.id === selectedRule.id);
    if (!saved) {
      if (!hasChanges(selectedRule)) { applyRules(); scheduleOverlay(); return; }
      site.rules.push(selectedRule);
      renderSavedList();
    }
    selectedRule.updatedAt = Date.now();
    applyRules();
    queueSave();
    updateUrlWatcher();
    scheduleOverlay();
  }

  function selectElement(element) {
    if (!(element instanceof Element) || element === editorHost || editorHost?.contains(element)) return;
    const matching = site.rules.filter((rule) => ruleIsHere(rule) && selectorMatches(element, rule.selector));
    const order = (rule) => SCOPE_ORDER[rule.scope] * 10 +
      (rule.matchLevel === "custom" ? 1.5 : 3 - rule.matchLevel);
    const existing = matching.sort((a, b) => order(a) - order(b)).at(-1);
    selectedElement = element;
    selectedRule = existing || makeDraft(element);
    manualOpen = selectedRule.matchLevel === "custom";
    manualPreviewSelector = null;
    hoveredElement = null;
    picking = false;
    renderSelection();
    renderSavedList();
    scheduleOverlay();
  }

  function showToast(message) {
    const toast = shadow?.getElementById("twk-toast");
    if (!toast) return;
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, 2800);
  }

  function isColorProperty(property) {
    return property === "color" || property === "fill" || property === "stroke" ||
      /(?:^|-)color$/.test(property);
  }

  function parseColorToHex(raw) {
    const value = String(raw || "").trim();
    const hex = value.match(/^#([a-f\d]{3,4}|[a-f\d]{6}|[a-f\d]{8})$/i);
    if (hex) {
      const digits = hex[1];
      return digits.length <= 4 ? `#${digits.slice(0, 3).split("").map((c) => c + c).join("")}`.toLowerCase()
        : `#${digits.slice(0, 6)}`.toLowerCase();
    }
    const rgb = value.match(/^rgba?\((.*)\)$/i);
    if (!rgb) return null;
    const parts = rgb[1].replace(/[,/]/g, " ").trim().split(/\s+/).slice(0, 3);
    if (parts.length !== 3) return null;
    const bytes = parts.map((part) => part.endsWith("%")
      ? Math.round(parseFloat(part) * 255 / 100) : Math.round(Number(part)));
    if (bytes.some((byte) => !Number.isFinite(byte))) return null;
    return `#${bytes.map((byte) => Math.max(0, Math.min(255, byte)).toString(16).padStart(2, "0")).join("")}`;
  }

  function pickerColor(property, value) {
    const direct = parseColorToHex(value);
    if (direct) return direct;
    try {
      if (value && CSS.supports("color", value) && !value.includes("var(")) {
        const context = document.createElement("canvas").getContext("2d");
        context.fillStyle = value;
        const named = parseColorToHex(context.fillStyle);
        if (named) return named;
      }
      if (selectedElement?.isConnected) {
        const computed = getComputedStyle(selectedElement).getPropertyValue(property);
        const current = parseColorToHex(computed);
        if (current) return current;
      }
    } catch { /* Unsupported color notation: leave the text editor usable. */ }
    return "#6851ea";
  }

  function opacityForSlider(value) {
    const raw = value.trim() || (selectedElement?.isConnected ? getComputedStyle(selectedElement).opacity : "1");
    const numeric = Number(raw);
    return Number.isFinite(numeric) ? Math.max(0, Math.min(1, numeric)) : 1;
  }

  function renderPropertyList() {
    const list = shadow?.getElementById("twk-property-list");
    if (!list || !selectedRule) return;
    const entries = Object.entries(selectedRule.props);
    if (!entries.length) {
      list.innerHTML = '<div class="twk-no-properties">No CSS properties yet. Add one below.</div>';
      return;
    }
    list.innerHTML = entries.map(([property, value]) => {
      const invalid = value.trim() !== "" && canonicalValue(property, value) === null;
      const colorPicker = isColorProperty(property)
        ? `<input type="color" class="twk-color-picker" data-color-property="${escapeHtml(property)}" value="${pickerColor(property, value)}" aria-label="Choose a color for ${escapeHtml(property)}" title="Choose color">` : "";
      const opacitySlider = property === "opacity"
        ? `<div class="twk-range-row"><span>0</span><input type="range" min="0" max="1" step="0.01" data-range-property="opacity" value="${opacityForSlider(value)}" aria-label="Opacity slider"><span>1</span></div>` : "";
      return `<div class="twk-property-block"><div class="twk-property-row">
        <div class="twk-property-name" title="${escapeHtml(property)}"><strong>${escapeHtml(PROPERTY_LABELS[property] || property)}</strong><small>${escapeHtml(property)}</small></div>
        <input class="twk-value-input" data-property-value="${escapeHtml(property)}" aria-label="Value for ${escapeHtml(property)}" aria-invalid="${invalid}" title="${invalid ? "This CSS value is not valid yet" : "Enter a CSS value"}" placeholder="${escapeHtml(PROPERTY_EXAMPLES[property] || "CSS value")}" value="${escapeHtml(value)}" spellcheck="false" autocomplete="off">
        ${colorPicker}
        <button type="button" class="twk-icon-button" data-action="remove-property" data-name="${escapeHtml(property)}" aria-label="Remove ${escapeHtml(property)}" title="Remove this property">${ICONS.trash}</button>
      </div>${opacitySlider}</div>`;
    }).join("");
  }

  function renderSavedList() {
    if (!shadow) return;
    const list = shadow.getElementById("twk-saved-list");
    shadow.getElementById("twk-count").textContent = String(site.rules.length);
    if (!site.rules.length) {
      list.innerHTML = '<div class="twk-saved-empty">Your changes will appear here automatically.</div>';
      return;
    }
    list.innerHTML = site.rules.slice().reverse().map((rule) => {
      const elsewhere = !ruleIsHere(rule);
      const label = rule.label || rule.selector;
      const scopeName = rule.scope === "section" ? "SECTION" : rule.scope === "page" ? "PAGE" : "DOMAIN";
      const locationNote = elsewhere ? `Only on ${rule.scope === "section" ? rule.sectionPath : rule.pathname}` : rule.selector;
      return `<div class="twk-saved-item">
        <button type="button" class="twk-saved-pick" data-action="select-rule" data-id="${escapeHtml(rule.id)}" title="${escapeHtml(locationNote)}" ${elsewhere ? "disabled" : ""}>
          <strong>${escapeHtml(label)}</strong><span class="twk-scope-badge">${scopeName}</span>
        </button>
        <button type="button" class="twk-icon-button" data-action="delete-rule" data-id="${escapeHtml(rule.id)}" title="Delete this saved edit" aria-label="Delete edit for ${escapeHtml(label)}">${ICONS.trash}</button>
      </div>`;
    }).join("");
  }

  function renderTargeting() {
    if (!shadow || !selectedRule) return;
    const count = safeFindAll(selectedRule.selector).length;
    shadow.getElementById("twk-match-count").textContent = `${count} ${count === 1 ? "match" : "matches"}`;
    const slider = shadow.getElementById("twk-specificity");
    slider.value = String(selectedRule.matchLevel === "custom" ? selectedRule.lastLevel : selectedRule.matchLevel);
    slider.disabled = !selectedElement?.isConnected;
    shadow.querySelectorAll(".twk-scale > span").forEach((tick) =>
      tick.classList.toggle("active", selectedRule.matchLevel === Number(tick.dataset.level)));
    shadow.getElementById("twk-all-type").textContent = selectedElement?.localName?.toLowerCase() || "type";
    shadow.getElementById("twk-match-explanation").textContent = selectedRule.matchLevel === "custom"
      ? "Custom selector active · moving the slider replaces it."
      : count === 0 ? "Nothing matches yet. It will apply when matching elements appear."
        : count > 60 ? `${MATCH_LABELS[selectedRule.matchLevel]} · affects ${count} elements here.`
          : MATCH_LABELS[selectedRule.matchLevel];
    const candidate = selectedRule.classFilter || Array.from(selectedElement?.classList || []).find(stableClass) || "";
    shadow.getElementById("twk-class-filter-wrap").hidden = !candidate || selectedRule.matchLevel === "custom";
    shadow.getElementById("twk-class-filter").checked = Boolean(selectedRule.classFilter);
    shadow.getElementById("twk-class-name").textContent = `.${candidate}`;
    shadow.getElementById("twk-manual-controls").hidden = !manualOpen;
    shadow.querySelector('[data-action="toggle-manual"]').textContent = manualOpen
      ? "Hide manual selector ↑" : "Edit CSS selector manually ↗";
    shadow.getElementById("twk-manual-selector").value = selectedRule.selector;
    shadow.getElementById("twk-manual-selector").setAttribute("aria-invalid", "false");
    shadow.getElementById("twk-manual-feedback").dataset.error = "false";
    shadow.getElementById("twk-manual-feedback").textContent =
      selectedRule.matchLevel === "custom" && site.rules.some((rule) => rule.id === selectedRule.id)
        ? "Manual selector saved. Change it and press Apply to update."
        : "Enter a CSS selector, then press Apply. Style edits save automatically.";
  }

  function renderScope() {
    if (!shadow || !selectedRule) return;
    for (const scope of ["site", "section", "page"]) {
      shadow.querySelector(`[data-scope="${scope}"]`).setAttribute("aria-pressed", String(selectedRule.scope === scope));
    }
    const sectionControls = shadow.getElementById("twk-section-controls");
    sectionControls.hidden = selectedRule.scope !== "section";
    shadow.getElementById("twk-section-path").value = selectedRule.sectionPath;
    shadow.getElementById("twk-scope-note").textContent = selectedRule.scope === "page"
      ? `Only on ${selectedRule.pathname} (query & hash ignored).`
      : selectedRule.scope === "section"
        ? `On ${location.hostname}${selectedRule.sectionPath} and paths beneath it.`
        : `On ${location.hostname} wherever the selector matches.`;
  }

  function renderSelection() {
    if (!shadow) return;
    const empty = shadow.getElementById("twk-empty");
    const selected = shadow.getElementById("twk-selected");
    empty.hidden = Boolean(selectedRule);
    selected.hidden = !selectedRule;
    if (!selectedRule) {
      shadow.getElementById("twk-empty-title").textContent = picking ? "Choose something to change" : "Ready when you are";
      shadow.getElementById("twk-empty-hint").textContent = picking
        ? "Hover over the page, then click the element you want to edit."
        : "Pick an element to move it or change its CSS.";
      const pickButton = shadow.getElementById("twk-pick-button");
      pickButton.textContent = picking ? "Click an element on the page" : "Pick an element";
      pickButton.disabled = picking;
      if (dirty || pendingSaves > 0) updateSaveLabel("Saving changes…", "saving");
      else updateSaveLabel("Changes save automatically", "saved");
      return;
    }

    const label = selectedRule.label || selectedRule.selector;
    shadow.getElementById("twk-target-name").textContent = label;
    shadow.getElementById("twk-target-name").title = label;
    shadow.getElementById("twk-selector").textContent = selectedRule.selector;
    shadow.getElementById("twk-selector").title = selectedRule.selector;
    shadow.getElementById("twk-x").value = String(selectedRule.x);
    shadow.getElementById("twk-y").value = String(selectedRule.y);
    renderTargeting();
    renderScope();
    renderPropertyList();
    if (dirty || pendingSaves > 0) updateSaveLabel("Saving changes…", "saving");
    else if (!selectedRule.selector.trim()) updateSaveLabel("Enter a CSS selector to begin", "saved");
    else updateSaveLabel(site.rules.some((rule) => rule.id === selectedRule.id)
      ? "All changes saved" : "Move it or edit a property to save", "saved");
  }

  function scheduleOverlay() {
    if (!shadow || overlayQueued) return;
    overlayQueued = true;
    requestAnimationFrame(() => {
      overlayQueued = false;
      updateOverlay();
    });
  }

  function updateOverlay() {
    if (!shadow) return;
    const outline = shadow.getElementById("twk-outline");
    const handle = shadow.getElementById("twk-handle");
    const group = shadow.getElementById("twk-group-outlines");
    group.replaceChildren();
    const selector = manualPreviewSelector !== null ? manualPreviewSelector : selectedRule?.selector;
    const matches = !picking && selector ? safeFindAll(selector) : [];
    const element = picking ? hoveredElement :
      (matches.includes(selectedElement) ? selectedElement : matches[0] || null);
    if (!picking && manualPreviewSelector === null && element) selectedElement = element;
    if (selectedRule) {
      const badge = shadow.getElementById("twk-match-count");
      badge.textContent = `${matches.length} ${matches.length === 1 ? "match" : "matches"}`;
    }
    if (!element?.isConnected) {
      outline.hidden = true;
      handle.hidden = true;
      return;
    }
    if (!picking && matches.length > 1) {
      let shown = 0;
      for (const matched of matches) {
        if (matched === element || shown >= 28) continue;
        const box = matched.getBoundingClientRect();
        if (box.width < 1 || box.height < 1 || box.bottom < 0 || box.top > innerHeight ||
            box.right < 0 || box.left > innerWidth) continue;
        const marker = document.createElement("div");
        marker.className = "twk-group-outline";
        marker.style.left = `${box.left - 1}px`;
        marker.style.top = `${box.top - 1}px`;
        marker.style.width = `${box.width + 2}px`;
        marker.style.height = `${box.height + 2}px`;
        group.appendChild(marker);
        shown++;
      }
    }
    const rect = element.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1 || rect.bottom < 0 || rect.top > innerHeight ||
        rect.right < 0 || rect.left > innerWidth) {
      outline.hidden = true;
      handle.hidden = true;
      return;
    }
    outline.hidden = false;
    outline.dataset.picking = String(picking);
    outline.dataset.below = String(rect.top < 30);
    outline.style.left = `${rect.left - 2}px`;
    outline.style.top = `${rect.top - 2}px`;
    outline.style.width = `${rect.width + 4}px`;
    outline.style.height = `${rect.height + 4}px`;
    shadow.getElementById("twk-outline-tag").textContent = picking ? "CLICK TO SELECT" :
      manualPreviewSelector !== null ? "SELECTOR PREVIEW" : "SELECTED ELEMENT";
    handle.hidden = picking || manualPreviewSelector !== null;
    if (!picking) {
      handle.style.left = `${Math.max(7, Math.min(innerWidth - 132, rect.left))}px`;
      handle.style.top = `${rect.top < 32 ? Math.min(innerHeight - 34, rect.bottom + 6) : rect.top - 32}px`;
    }
  }

  function isEditorEvent(event) {
    return Boolean(editorHost && event.composedPath?.().includes(editorHost));
  }

  function handlePageMove(event) {
    if (!picking || isEditorEvent(event)) return;
    hoveredElement = event.target instanceof Element ? event.target : null;
    scheduleOverlay();
  }

  function handlePageDown(event) {
    if (!picking || isEditorEvent(event) || event.button !== 0) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  function handlePageUp(event) {
    if (!picking || isEditorEvent(event) || event.button !== 0) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    swallowClickUntil = performance.now() + 350;
    selectElement(event.target);
  }

  function handlePageClick(event) {
    if (isEditorEvent(event) || (!picking && performance.now() > swallowClickUntil)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    swallowClickUntil = 0;
    if (picking) selectElement(event.target);
  }

  function handleEscape(event) {
    if (event.key !== "Escape" || !editorHost) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (picking) {
      picking = false;
      hoveredElement = null;
      renderSelection();
      scheduleOverlay();
    } else closeEditor();
  }

  function startPicking() {
    selectedElement = null;
    selectedRule = null;
    manualPreviewSelector = null;
    manualOpen = false;
    hoveredElement = null;
    picking = true;
    renderSelection();
    renderSavedList();
    scheduleOverlay();
  }

  function removeRule(id) {
    const existing = site.rules.find((rule) => rule.id === id);
    if (!existing) return;
    site.rules = site.rules.filter((rule) => rule.id !== id);
    if (selectedRule?.id === id) {
      selectedRule = selectedElement?.isConnected ? makeDraft(selectedElement) : null;
      manualOpen = false;
      manualPreviewSelector = null;
      picking = !selectedRule;
    }
    applyRules();
    queueSave();
    updateUrlWatcher();
    renderSelection();
    renderSavedList();
    showToast("Saved edit removed");
  }

  function addProperty() {
    if (!selectedRule) return;
    const preset = shadow.getElementById("twk-preset").value;
    let property = preset === "custom" ? shadow.getElementById("twk-custom-name").value.trim() : preset;
    if (!property.startsWith("--")) property = property.toLowerCase();
    if (!validPropertyName(property)) {
      showToast("Enter a CSS property name, like letter-spacing");
      return;
    }
    if (!property.startsWith("--") && !CSS.supports(property, "initial")) {
      showToast("That CSS property isn't supported by Chrome");
      return;
    }
    if (!Object.prototype.hasOwnProperty.call(selectedRule.props, property)) {
      selectedRule.props[property] = "";
      renderPropertyList();
    }
    const input = Array.from(shadow.querySelectorAll("[data-property-value]"))
      .find((item) => item.dataset.propertyValue === property);
    input?.focus();
    input?.select();
  }

  function checkManualSelector(raw) {
    const selector = raw.trim();
    if (!selector) return { error: "Enter a CSS selector." };
    if (selector.length > 1500) return { error: "Keep the selector under 1,500 characters." };
    try {
      const matches = Array.from(document.querySelectorAll(selector)).filter((element) =>
        element !== editorHost && !editorHost?.contains(element));
      return { selector, matches };
    } catch { return { error: "Invalid CSS selector — check the syntax." }; }
  }

  function previewManualSelector() {
    const input = shadow.getElementById("twk-manual-selector");
    const feedback = shadow.getElementById("twk-manual-feedback");
    const result = checkManualSelector(input.value);
    input.setAttribute("aria-invalid", String(Boolean(result.error)));
    feedback.dataset.error = String(Boolean(result.error));
    feedback.textContent = result.error || `${result.matches.length} ${result.matches.length === 1 ? "element" : "elements"} match on this page. Press Apply to save.`;
    manualPreviewSelector = result.error ? null : result.selector;
    scheduleOverlay();
  }

  function applyManualSelector() {
    if (!selectedRule) return;
    const input = shadow.getElementById("twk-manual-selector");
    const result = checkManualSelector(input.value);
    if (result.error) {
      input.setAttribute("aria-invalid", "true");
      shadow.getElementById("twk-manual-feedback").textContent = result.error;
      shadow.getElementById("twk-manual-feedback").dataset.error = "true";
      return;
    }
    selectedRule.selector = result.selector;
    selectedRule.matchLevel = "custom";
    manualPreviewSelector = null;
    if (result.matches.length && !result.matches.includes(selectedElement)) selectedElement = result.matches[0];
    if (selectedElement?.isConnected && result.matches.includes(selectedElement))
      selectedRule.anchorSelector = selectorFor(selectedElement);
    markChanged();
    renderSelection();
    renderSavedList();
    scheduleOverlay();
    const saved = site.rules.some((rule) => rule.id === selectedRule.id);
    showToast(!saved ? "Target ready — make a style edit to save it" : result.matches.length
      ? `Selector applied to ${result.matches.length} ${result.matches.length === 1 ? "element" : "elements"}`
      : "Selector saved; no matches on this page yet");
  }

  function handlePanelClick(event) {
    // A page can see an open shadow root, but it cannot forge trusted UI input.
    if (!event.isTrusted) return;
    const button = event.target.closest?.("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    if (action === "close") closeEditor();
    else if (action === "pick") startPicking();
    else if (action === "manual-new") {
      const seed = document.body || document.documentElement;
      selectedRule = makeDraft(seed);
      selectedRule.selector = "";
      selectedRule.label = "Custom selector";
      selectedRule.matchLevel = "custom";
      selectedElement = null;
      picking = false;
      manualOpen = true;
      manualPreviewSelector = null;
      renderSelection();
      renderSavedList();
      scheduleOverlay();
      shadow.getElementById("twk-manual-selector").focus();
    } else if (action === "add-property") addProperty();
    else if (action === "toggle-manual" && selectedRule) {
      manualOpen = !manualOpen;
      manualPreviewSelector = null;
      renderTargeting();
      if (manualOpen) shadow.getElementById("twk-manual-selector").focus();
      scheduleOverlay();
    } else if (action === "apply-manual") applyManualSelector();
    else if (action === "reset-position" && selectedRule) {
      selectedRule.x = 0;
      selectedRule.y = 0;
      shadow.getElementById("twk-x").value = "0";
      shadow.getElementById("twk-y").value = "0";
      markChanged();
    } else if (action === "remove-property" && selectedRule) {
      delete selectedRule.props[button.dataset.name];
      markChanged();
      renderPropertyList();
    } else if (action === "scope" && selectedRule) {
      selectedRule.scope = button.dataset.scope;
      if (selectedRule.scope === "page") selectedRule.pathname = location.pathname;
      if (selectedRule.scope === "section" && !selectedRule.sectionPath)
        selectedRule.sectionPath = defaultSectionPath(location.pathname);
      if (site.rules.some((rule) => rule.id === selectedRule.id)) markChanged();
      renderScope();
      renderSavedList();
      updateUrlWatcher();
    } else if (action === "delete-rule") removeRule(button.dataset.id);
    else if (action === "select-rule") {
      const rule = site.rules.find((item) => item.id === button.dataset.id);
      if (!rule || !ruleIsHere(rule)) return;
      const matches = safeFindAll(rule.selector);
      const anchor = safeFind(rule.anchorSelector);
      const element = matches.includes(anchor) ? anchor : matches[0];
      selectedRule = rule;
      selectedElement = element || null;
      manualOpen = rule.matchLevel === "custom" || !element;
      manualPreviewSelector = null;
      hoveredElement = null;
      picking = false;
      renderSelection();
      scheduleOverlay();
      if (!element) showToast("No matches here — edit the selector to retarget it");
    }
  }

  function handlePanelInput(event) {
    if (!event.isTrusted) return;
    const target = event.target;
    if (!selectedRule) return;
    if (target.id === "twk-specificity") {
      if (!selectedElement?.isConnected) { showToast("Pick an element before adjusting the slider"); return; }
      const level = Number(target.value);
      selectedRule.selector = selectorAtLevel(selectedElement, level, selectedRule.classFilter);
      selectedRule.matchLevel = level;
      selectedRule.lastLevel = level;
      if (level === 0) selectedRule.anchorSelector = selectedRule.selector;
      manualOpen = false;
      manualPreviewSelector = null;
      markChanged();
      renderSelection();
      renderSavedList();
    } else if (target.id === "twk-class-filter") {
      if (!selectedElement?.isConnected || selectedRule.matchLevel === "custom") return;
      const candidate = Array.from(selectedElement.classList || []).find(stableClass) || selectedRule.classFilter;
      selectedRule.classFilter = target.checked ? candidate || "" : "";
      selectedRule.selector = selectorAtLevel(selectedElement, selectedRule.matchLevel, selectedRule.classFilter);
      markChanged();
      renderTargeting();
      renderSavedList();
    } else if (target.id === "twk-manual-selector") {
      previewManualSelector();
    } else if (target.id === "twk-section-path") {
      const path = normalizeSectionPath(target.value);
      target.setAttribute("aria-invalid", String(!path));
      shadow.getElementById("twk-scope-note").textContent = path
        ? `On ${location.hostname}${path} and paths beneath it.` : "Enter a path beginning with / (e.g. /watch).";
      if (path && path !== selectedRule.sectionPath) {
        selectedRule.sectionPath = path;
        if (site.rules.some((rule) => rule.id === selectedRule.id)) markChanged();
        renderSavedList();
      }
    } else if (target.id === "twk-x" || target.id === "twk-y") {
      if (target.value === "" || !Number.isFinite(Number(target.value))) return;
      const key = target.id === "twk-x" ? "x" : "y";
      const value = clampNumber(target.value);
      if (selectedRule[key] === value) return;
      selectedRule[key] = value;
      markChanged();
    } else if (target.dataset.colorProperty || target.dataset.rangeProperty) {
      const property = target.dataset.colorProperty || target.dataset.rangeProperty;
      const value = target.dataset.rangeProperty ? String(Number(target.value)) : target.value;
      selectedRule.props[property] = value;
      const textInput = Array.from(shadow.querySelectorAll("[data-property-value]"))
        .find((item) => item.dataset.propertyValue === property);
      if (textInput) {
        textInput.value = value;
        textInput.setAttribute("aria-invalid", "false");
      }
      markChanged();
    } else if (target.dataset.propertyValue) {
      const property = target.dataset.propertyValue;
      selectedRule.props[property] = target.value.slice(0, 2000);
      const invalid = target.value.trim() !== "" && canonicalValue(property, target.value) === null;
      target.setAttribute("aria-invalid", String(invalid));
      target.title = invalid ? "This CSS value is not valid yet" : "Enter a CSS value";
      if (isColorProperty(property)) {
        const picker = Array.from(shadow.querySelectorAll("[data-color-property]"))
          .find((item) => item.dataset.colorProperty === property);
        if (picker && !invalid && target.value.trim()) picker.value = pickerColor(property, target.value);
      }
      if (property === "opacity" && Number.isFinite(Number(target.value)) && target.value.trim()) {
        const slider = shadow.querySelector('[data-range-property="opacity"]');
        if (slider) slider.value = String(opacityForSlider(target.value));
      }
      markChanged();
    }
  }

  function handlePanelChange(event) {
    if (event.target.id === "twk-preset") {
      const custom = event.target.value === "custom";
      shadow.getElementById("twk-custom-name").hidden = !custom;
      if (custom) shadow.getElementById("twk-custom-name").focus();
    } else if (event.target.id === "twk-section-path" && selectedRule) {
      event.target.value = selectedRule.sectionPath;
      event.target.setAttribute("aria-invalid", "false");
      renderScope();
    } else if (event.target.id === "twk-x" || event.target.id === "twk-y") {
      if (selectedRule) event.target.value = String(selectedRule[event.target.id === "twk-x" ? "x" : "y"]);
    }
  }

  function handlePanelKeydown(event) {
    if (!event.isTrusted) return;
    if (event.key === "Enter" && event.target.id === "twk-custom-name") {
      event.preventDefault();
      addProperty();
    } else if (event.key === "Enter" && event.target.id === "twk-manual-selector") {
      event.preventDefault();
      applyManualSelector();
    }
  }

  function handleDragDown(event) {
    if (!event.isTrusted || !selectedRule || !selectedElement?.isConnected || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    drag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY,
      x: selectedRule.x, y: selectedRule.y };
    event.currentTarget.setPointerCapture(event.pointerId);
    event.currentTarget.classList.add("dragging");
  }

  function handleDragMove(event) {
    if (!event.isTrusted || !drag || event.pointerId !== drag.pointerId || !selectedRule) return;
    const x = clampNumber(drag.x + event.clientX - drag.startX);
    const y = clampNumber(drag.y + event.clientY - drag.startY);
    if (x === selectedRule.x && y === selectedRule.y) return;
    selectedRule.x = x;
    selectedRule.y = y;
    shadow.getElementById("twk-x").value = String(x);
    shadow.getElementById("twk-y").value = String(y);
    markChanged();
  }

  function handleDragEnd(event) {
    if (!event.isTrusted || !drag || event.pointerId !== drag.pointerId) return;
    drag = null;
    event.currentTarget.classList.remove("dragging");
    if (dirty) void persistNow();
  }

  function createEditor() {
    if (editorHost || !document.documentElement) return;
    editorHost = document.createElement("div");
    editorHost.id = "tweaklet-editor-root";
    editorHost.style.setProperty("position", "fixed", "important");
    editorHost.style.setProperty("inset", "0", "important");
    editorHost.style.setProperty("z-index", "2147483647", "important");
    editorHost.style.setProperty("pointer-events", "none", "important");
    shadow = editorHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <div id="twk-group-outlines" aria-hidden="true"></div>
      <div id="twk-outline" hidden><span id="twk-outline-tag" class="twk-outline-tag">CLICK TO SELECT</span></div>
      <button type="button" id="twk-handle" title="Drag to move this element" hidden>${ICONS.drag}<span>DRAG TO MOVE</span></button>
      <aside id="twk-panel" aria-label="Tweaklet page editor">
        <div class="twk-topbar">
          <div class="twk-logo">${ICONS.cursor}</div>
          <div class="twk-brand"><strong>tweaklet.</strong><span>LIVE PAGE EDITOR</span></div>
          <button type="button" class="twk-close" data-action="close" title="Finish editing" aria-label="Finish editing">${ICONS.close}</button>
        </div>
        <div class="twk-content">
          <div class="twk-context"><span class="twk-live-dot"></span>Editing <strong id="twk-hostname"></strong><span class="twk-context-suffix">on this device</span></div>
          <div id="twk-empty" class="twk-empty">
            <div class="twk-empty-graphic">${ICONS.target}</div>
            <h2 id="twk-empty-title">Choose something to change</h2>
            <p id="twk-empty-hint">Hover over the page, then click the element you want to edit.</p>
            <button type="button" id="twk-pick-button" class="twk-pick-button" data-action="pick" disabled>Click an element on the page</button>
            <button type="button" class="twk-empty-manual" data-action="manual-new">Use a CSS selector instead →</button>
          </div>
          <div id="twk-selected" hidden>
            <div class="twk-target"><span class="twk-target-icon">${ICONS.target}</span><div class="twk-target-copy"><small>SELECTED ELEMENT</small><strong id="twk-target-name"></strong></div><button type="button" class="twk-change-target" data-action="pick">Change</button></div>
            <div id="twk-selector" class="twk-selector"></div>
            <section class="twk-section twk-targeting" aria-label="Element targeting">
              <div class="twk-section-header"><h3>WHICH ELEMENTS?</h3><span id="twk-match-count" class="twk-match-pill">1 match</span></div>
              <input id="twk-specificity" class="twk-specificity" type="range" min="0" max="3" step="1" value="0" aria-label="How broadly to match similar elements">
              <div class="twk-scale"><span data-level="0">Exact</span><span data-level="1">Siblings</span><span data-level="2">Area</span><span data-level="3">All &lt;<span id="twk-all-type">type</span>&gt;</span></div>
              <p id="twk-match-explanation" class="twk-targeting-note">Only this element</p>
              <label id="twk-class-filter-wrap" class="twk-class-filter" hidden><input id="twk-class-filter" type="checkbox"> For groups, match only <code id="twk-class-name"></code></label>
              <button type="button" class="twk-manual-toggle" data-action="toggle-manual">Edit CSS selector manually ↗</button>
              <div id="twk-manual-controls" class="twk-manual-controls" hidden>
                <div class="twk-manual-row"><input id="twk-manual-selector" type="text" placeholder="e.g. .video-player button" maxlength="1500" aria-label="Manual CSS selector" spellcheck="false" autocomplete="off"><button type="button" data-action="apply-manual">Apply</button></div>
                <p id="twk-manual-feedback" class="twk-manual-feedback" role="status"></p>
              </div>
            </section>
            <section class="twk-section"><div class="twk-section-header"><h3>POSITION</h3><span>Offset from original spot</span></div>
              <div class="twk-coords">
                <div class="twk-coordinate"><label for="twk-x">X</label><input id="twk-x" type="number" step="1" aria-label="Horizontal offset in pixels"><span class="twk-px">px</span></div>
                <div class="twk-coordinate"><label for="twk-y">Y</label><input id="twk-y" type="number" step="1" aria-label="Vertical offset in pixels"><span class="twk-px">px</span></div>
                <button type="button" class="twk-reset" data-action="reset-position" title="Reset the position">Reset</button>
              </div><p class="twk-help">Drag the purple handle on the element, or enter X and Y.</p>
            </section>
            <section class="twk-section"><div class="twk-section-header"><h3>CSS PROPERTIES</h3><span>Edit any style</span></div>
              <div id="twk-property-list" class="twk-property-list"></div>
              <div class="twk-add-row"><select id="twk-preset" class="twk-preset" aria-label="Choose a CSS property">
                <option value="color">Text color</option><option value="background-color">Background</option><option value="font-size">Font size</option><option value="font-weight">Font weight</option>
                <option value="opacity">Opacity</option><option value="width">Width</option><option value="height">Height</option><option value="border-radius">Corner radius</option>
                <option value="border-color">Border color</option><option value="outline-color">Outline color</option><option value="fill">SVG fill</option><option value="stroke">SVG stroke</option>
                <option value="display">Display</option><option value="padding">Padding</option><option value="margin">Margin</option><option value="border">Border</option>
                <option value="box-shadow">Shadow</option><option value="z-index">Layer (z-index)</option><option value="custom">Custom CSS property…</option>
              </select><button type="button" class="twk-add-button" data-action="add-property">+ Add</button></div>
              <input id="twk-custom-name" class="twk-custom-name" placeholder="e.g. letter-spacing" aria-label="Custom CSS property name" spellcheck="false" autocomplete="off" hidden>
            </section>
            <section class="twk-section twk-scope"><div class="twk-section-header"><h3>WHERE TO APPLY</h3><span>Choose a scope</span></div>
              <div class="twk-segments"><button type="button" data-action="scope" data-scope="site" aria-pressed="true">Domain</button><button type="button" data-action="scope" data-scope="section" aria-pressed="false">Section</button><button type="button" data-action="scope" data-scope="page" aria-pressed="false">This page</button></div>
              <div id="twk-section-controls" class="twk-section-controls" hidden><label for="twk-section-path">Path prefix</label><input id="twk-section-path" type="text" placeholder="/watch" aria-label="Section path prefix" spellcheck="false" autocomplete="off"><small>e.g. /watch includes /watch and /watch/clip, not /watchlist</small></div>
              <p id="twk-scope-note" class="twk-scope-note"></p>
            </section>
          </div>
        </div>
        <section class="twk-saved" aria-label="Saved edits on this domain"><div class="twk-saved-head"><strong>Saved on this domain</strong><span id="twk-count" class="twk-count">0</span></div><div id="twk-saved-list" class="twk-saved-list"></div></section>
        <div id="twk-footer" class="twk-footer" data-kind="saved"><span class="twk-status-dot"></span><span id="twk-status">Changes save automatically</span><span class="twk-footer-privacy">LOCAL ONLY</span></div>
      </aside>
      <div id="twk-toast" role="status" hidden></div>`;

    // Constructed CSS works inside the shadow root without relying on the site's
    // inline-style policy. Shadow DOM also keeps the website's styles out.
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(globalThis.__TWEAKLET_EDITOR_CSS);
      shadow.adoptedStyleSheets = [sheet];
    } catch {
      const style = document.createElement("style");
      style.textContent = globalThis.__TWEAKLET_EDITOR_CSS;
      shadow.prepend(style);
    }
    document.documentElement.appendChild(editorHost);
    shadow.getElementById("twk-hostname").textContent = location.hostname;
    shadow.getElementById("twk-panel").addEventListener("click", handlePanelClick);
    shadow.getElementById("twk-panel").addEventListener("input", handlePanelInput);
    shadow.getElementById("twk-panel").addEventListener("change", handlePanelChange);
    shadow.getElementById("twk-panel").addEventListener("keydown", handlePanelKeydown);
    const handle = shadow.getElementById("twk-handle");
    handle.addEventListener("pointerdown", handleDragDown);
    handle.addEventListener("pointermove", handleDragMove);
    handle.addEventListener("pointerup", handleDragEnd);
    handle.addEventListener("pointercancel", handleDragEnd);
    document.addEventListener("pointermove", handlePageMove, true);
    document.addEventListener("pointerdown", handlePageDown, true);
    document.addEventListener("pointerup", handlePageUp, true);
    document.addEventListener("click", handlePageClick, true);
    document.addEventListener("keydown", handleEscape, true);
    document.addEventListener("scroll", scheduleOverlay, true);
    window.addEventListener("resize", scheduleOverlay);
    picking = true;
    renderSelection();
    renderSavedList();
    updateUrlWatcher();
  }

  function closeEditor() {
    if (!editorHost) return;
    if (dirty) void persistNow();
    document.removeEventListener("pointermove", handlePageMove, true);
    document.removeEventListener("pointerdown", handlePageDown, true);
    document.removeEventListener("pointerup", handlePageUp, true);
    document.removeEventListener("click", handlePageClick, true);
    document.removeEventListener("keydown", handleEscape, true);
    document.removeEventListener("scroll", scheduleOverlay, true);
    window.removeEventListener("resize", scheduleOverlay);
    editorHost.remove();
    editorHost = null;
    shadow = null;
    picking = false;
    hoveredElement = null;
    selectedElement = null;
    selectedRule = null;
    manualPreviewSelector = null;
    manualOpen = false;
    drag = null;
    swallowClickUntil = 0;
    clearTimeout(toastTimer);
    updateUrlWatcher();
  }

  function status() {
    return { hostname: location.hostname, paused: site.paused,
      ruleCount: site.rules.length, editing: Boolean(editorHost) };
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[SITE_KEY]) return;
    const next = normalizeSite(changes[SITE_KEY].newValue);
    if (next.lastWriter === INSTANCE_ID || dirty) return;
    site = next;
    if (site.paused) closeEditor();
    else if (selectedRule && site.rules.some((rule) => rule.id === selectedRule.id)) {
      selectedRule = site.rules.find((rule) => rule.id === selectedRule.id);
    }
    applyRules();
    renderSelection();
    renderSavedList();
    updateUrlWatcher();
  });

  const ready = chrome.storage.local.get(SITE_KEY).then((result) => {
    site = normalizeSite(result[SITE_KEY]);
    observePage();
    applyRules();
    updateUrlWatcher();
  }).catch((error) => {
    console.warn("Tweaklet couldn't load saved edits:", error);
    observePage();
  });

  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (!request || typeof request.type !== "string" || !request.type.startsWith("TWEAKLET_")) return false;
    ready.then(async () => {
      if (request.type === "TWEAKLET_GET_STATUS") {
        // No-op: just reply with status below.
      } else if (request.type === "TWEAKLET_SET_EDITOR") {
        if (request.enabled && site.paused) throw new Error("Resume changes to start editing.");
        if (request.enabled && !editorHost) {
          if (!document.documentElement) await new Promise((resolve) => document.addEventListener("DOMContentLoaded", resolve, { once: true }));
          createEditor();
        } else if (!request.enabled) closeEditor();
      } else if (request.type === "TWEAKLET_START_PICKING") {
        if (site.paused) throw new Error("Resume changes before selecting an element.");
        if (!document.documentElement) await new Promise((resolve) => document.addEventListener("DOMContentLoaded", resolve, { once: true }));
        if (!editorHost) createEditor();
        else startPicking();
      } else if (request.type === "TWEAKLET_SET_PAUSED") {
        site.paused = Boolean(request.paused);
        if (site.paused) closeEditor();
        applyRules();
        dirty = true;
        await persistNow();
      } else if (request.type === "TWEAKLET_CLEAR_SITE") {
        site.rules = [];
        site.paused = false;
        selectedElement = null;
        selectedRule = null;
        manualOpen = false;
        manualPreviewSelector = null;
        hoveredElement = null;
        picking = Boolean(editorHost);
        applyRules();
        renderSelection();
        renderSavedList();
        updateUrlWatcher();
        dirty = true;
        await persistNow();
      } else {
        throw new Error("Unknown Tweaklet command.");
      }
      sendResponse(status());
    }).catch((error) => sendResponse({ error: error.message || "Tweaklet couldn't complete that action." }));
    return true;
  });
})();
