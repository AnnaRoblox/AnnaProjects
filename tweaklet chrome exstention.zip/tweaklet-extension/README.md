# Tweaklet 1.1

**Change a website once. Keep it that way.** Select page elements, move them, or change their CSS. Tweaklet saves your edits locally and reapplies them whenever you return.

## Install or update

**New installation:**

1. Unzip `tweaklet-extension.zip`.
2. Open **`chrome://extensions`** and enable **Developer mode**.
3. Click **Load unpacked** and select the unzipped `tweaklet-extension` folder (the folder containing `manifest.json`).
4. Reload websites that were already open. Click or pin the Tweaklet icon.

**Updating from Tweaklet 1.0:** Replace the files in the *same existing extension folder*, click **Reload** on Tweaklet's card at `chrome://extensions`, and reload your website tabs. Keeping the same folder keeps the extension ID and your saved edits. Previously saved edits work in 1.1 without conversion. Loading it as a second unpacked extension from another folder may give it a different extension ID and separate storage.

The ZIP cannot be loaded directly using **Load unpacked**; unzip it first.

## Edit a page

1. Open an ordinary HTTP/HTTPS website. Click Tweaklet → **Start editing this page**, or use the keyboard shortcut.
2. Hover and click the element you want to change. Clicking a link *while picking* selects it instead of opening it.
3. **Move:** drag the purple handle or enter X/Y offsets in pixels.
4. **Restyle:** choose a CSS property → **+ Add** → type a CSS value. Pick **Custom CSS property…** for any supported property name. Color properties (including custom-added ones such as `border-color`) get a color picker; `opacity` gets a slider. The text input is always available for values such as `var(--brand)` and `calc(...)`.
5. Changes auto-save after a short pause. Finish editing and revisit the site to see them reapplied.

### Target one element or many

Use **Which elements?** to adjust the matching slider:

| Setting | Matches |
| --- | --- |
| **Exact** | Only the selected element (default) |
| **Siblings** | Same HTML tag under its immediate parent |
| **Area** | Same HTML tag in a nearby section/landmark |
| **All `<tag>`** | That HTML tag across the page |

When the element has a usable CSS class, check **For groups, match only `.class`** to limit Siblings, Area, or All to that class. The editor shows how many elements match on the current page and outlines visible matches. Group edits also apply to matching elements added later.

Click **Edit CSS selector manually** to enter any CSS selector (for example, `.video-player button`, `button.primary`, or `[data-testid="play"]`). Or choose **Use a CSS selector instead** before clicking any element, to target something that's hidden or hard to click. You can preview the match count as you type; press **Apply** to use the selector, then make a style edit to save a new rule. Invalid selectors are rejected. A selector with zero current matches can be saved, so it can apply when an element appears later. Moving the slider again replaces the manual selector with a generated one.

### Choose where an edit applies

- **Domain:** Current hostname, wherever the selector matches (default).
- **Section:** An editable URL **path prefix**, such as `/watch`. This matches `/watch` and `/watch/clip`, **not** `/watchlist`. It ignores query strings and URL fragments, so YouTube video URLs at `/watch?v=...` match the `/watch` section.
- **This page:** Exactly this URL path; also ignores query strings and fragments.

`youtube.com/watch` is a **path**, not a DNS subdomain. Tweaklet's Section option implements that example. Actual subdomains such as `music.youtube.com` and `www.youtube.com` remain separate hostnames.

### Keyboard shortcut

Press **Alt+Shift+E** (or **Command+Shift+E** on Mac) to open Tweaklet directly in selection mode, or to start picking a new element while its editor is already open. To change or remove the shortcut, click **Change** next to **Quick Pick** in the popup, or go to **`chrome://extensions/shortcuts`** and find **Tweaklet → Pick an element on the current page**. Chrome may leave the suggested shortcut unassigned if it conflicts with another shortcut; you can assign it there.

## Undo and privacy

- Open the editor and choose a saved edit to modify it, even if its selector currently matches no elements. Use the trash icon to remove an edit.
- Pause/resume all edits on a hostname with the popup switch, or use **Remove all changes on this domain** to clear them.
- If you hide something using `display: none`, its edit stays in the saved list for removal.

Edits live only in **`chrome.storage.local`** on your browser. Tweaklet has no account, analytics, background server, or outbound requests. Chrome asks for website access so saved edits can reapply on HTTP/HTTPS pages even when the popup is closed. `activeTab` lets the popup and keyboard command talk to the current tab.

**Limitations:** Chrome's internal pages, the Chrome Web Store, PDF viewers, `file://` pages, and elements *inside* cross-origin iframes or shadow roots cannot be edited directly. A site's markup changes can break a saved selector. Position offsets use CSS `translate`, so the element's original layout space remains in place; edits don't change the site's server or other people's browsers.

## Source and tests

- `manifest.json`, `background.js` — Manifest V3 setup and configurable shortcut
- `popup.html`, `popup.css`, `popup.js` — extension popup
- `editor-styles.js`, `content.js` — in-page editor and automatic reapplication
- `icons/` — extension icons
- `tests/smoke.js`, `tests/features.js` — optional Chromium integration tests

To run tests locally: `npm install --no-save playwright`, `npx playwright install chromium`, then `node tests/smoke.js && node tests/features.js`. On some Linux environments Playwright also needs `npx playwright install-deps chromium`.
