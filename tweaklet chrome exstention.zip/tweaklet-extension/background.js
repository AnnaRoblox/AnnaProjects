// The command appears under chrome://extensions/shortcuts and can be rebound there.
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "pick-element") return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id != null) {
      await chrome.tabs.sendMessage(tab.id, { type: "TWEAKLET_START_PICKING" });
    }
  } catch {
    // Chrome pages and tabs opened before installation do not have a content script.
  }
});
