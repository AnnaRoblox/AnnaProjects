/* Extended integration test: npm install --no-save playwright && npx playwright install chromium && node tests/features.js */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require("playwright");

const extensionPath = path.resolve(__dirname, "..");
const profile = fs.mkdtempSync(path.join(os.tmpdir(), "tweaklet-features-"));
const html = `<!doctype html><html><head><link rel="stylesheet" href="/style.css"></head><body>
<main id="content"><section id="cards"><div id="row-one">
<button class="chip">One</button><button class="chip">Two</button><button class="secondary">Three</button>
</div><div id="row-two"><button class="chip">Four</button></div></section>
<section id="other-area"><button class="chip">Five</button></section></main>
<footer><button class="chip">Six</button></footer></body></html>`;
const server = http.createServer((request, response) => {
  response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'none'; style-src 'self'; style-src-attr 'none'");
  if (request.url === "/style.css") {
    response.setHeader("Content-Type", "text/css");
    response.end("body{margin:0;background:#f9f8ff;font:14px Arial}main{padding:90px 80px 10px}section{margin-bottom:20px}button{display:block;width:130px;height:35px;margin-bottom:10px;color:rgb(30,40,50);border:1px solid #aaa;background:white}footer{padding:5px 80px}");
  } else {
    response.setHeader("Content-Type", "text/html");
    response.end(html);
  }
});

(async () => {
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const context = await chromium.launchPersistentContext(profile, {
    channel: "chromium", headless: process.env.TWEAKLET_HEADED !== "1", viewport: { width: 1240, height: 960 },
    args: [`--disable-extensions-except=${extensionPath}`, `--load-extension=${extensionPath}`]
  });
  try {
    const extensionTab = await context.newPage();
    await extensionTab.goto("chrome://extensions");
    const id = await extensionTab.locator("extensions-item").first().getAttribute("id");
    assert.match(id, /^[a-p]{32}$/);
    const page = await context.newPage();
    page.on("console", (msg) => { if (msg.type() === "error") console.log("site console:", msg.text()); });
    await page.goto(`${base}/watch/first`);
    const popup = await context.newPage();
    await popup.goto(`chrome-extension://${id}/popup.html`);
    await page.bringToFront();
    await popup.reload();
    await popup.waitForFunction(() => document.querySelector("#hostname")?.textContent === "127.0.0.1");
    const commands = await popup.evaluate(() => chrome.commands.getAll());
    assert(commands.some((entry) => entry.name === "pick-element"), "Chrome should register a configurable shortcut");
    const shortcut = commands.find((entry) => entry.name === "pick-element").shortcut;
    assert.equal(await popup.locator("#shortcut-key").innerText(), shortcut || "Not set");
    const shortcutsPageOpened = context.waitForEvent("page");
    await popup.evaluate(() => document.getElementById("shortcut-edit").click());
    const shortcutsPage = await shortcutsPageOpened;
    await shortcutsPage.waitForLoadState("domcontentloaded");
    assert.match(shortcutsPage.url(), /^chrome:\/\/extensions\/shortcuts/);
    await page.bringToFront();
    if (process.env.TWEAKLET_SCREENSHOT) {
      await popup.locator("main.app").screenshot({ path: path.join(path.dirname(process.env.TWEAKLET_SCREENSHOT), "tweaklet-popup-v1.1.png") });
    }

    async function send(type, extra = {}) {
      await page.bringToFront();
      return popup.evaluate(({ type, extra }) => new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
          chrome.tabs.sendMessage(tab.id, { type, ...extra }, (response) => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else if (response?.error) reject(new Error(response.error));
            else resolve(response);
          });
        });
      }), { type, extra });
    }
    const root = page.locator("#tweaklet-editor-root");
    // A real shortcut should start picking; the direct command is a fallback
    // if a headless browser does not route global shortcuts to extensions.
    let keyboardWorked = false;
    if (shortcut) {
      if (process.env.TWEAKLET_OS_SHORTCUT === "1") {
        require("node:child_process").execFileSync("xdotool", ["key", "--clearmodifiers", "alt+shift+e"]);
      } else {
        await page.keyboard.press(shortcut).catch(() => {});
      }
      keyboardWorked = await root.waitFor({ timeout: 1500 }).then(() => true).catch(() => false);
    }
    if (!keyboardWorked) await send("TWEAKLET_START_PICKING");
    await root.waitFor();
    assert.equal(await root.locator("#twk-empty-title").innerText(), "Choose something to change");

    const buttons = page.locator("button");
    await buttons.nth(0).click();
    await root.locator("#twk-preset").selectOption("opacity");
    await root.locator('[data-action="add-property"]').click();
    assert.equal(await root.locator('[data-range-property="opacity"]').count(), 1);
    await root.locator('[data-property-value="opacity"]').fill("0.5");
    await page.waitForFunction(() => getComputedStyle(document.querySelectorAll("button")[0]).opacity === "0.5");
    assert.equal(await buttons.nth(1).evaluate((el) => getComputedStyle(el).opacity), "1", "exact selection must not affect siblings");

    const range = root.locator("#twk-specificity");
    await range.focus();
    await range.press("ArrowRight");
    await page.waitForFunction(() => [...document.querySelectorAll("#row-one button")].every((el) => getComputedStyle(el).opacity === "0.5"));
    assert.equal(await buttons.nth(3).evaluate((el) => getComputedStyle(el).opacity), "1", "sibling mode should stay within the parent");
    await range.press("ArrowRight");
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#row-two button")).opacity === "0.5");
    assert.equal(await buttons.nth(4).evaluate((el) => getComputedStyle(el).opacity), "1", "area mode should stay in its section");
    await range.press("ArrowRight");
    await page.waitForFunction(() => [...document.querySelectorAll("button")].every((el) => getComputedStyle(el).opacity === "0.5"));
    assert.equal(await root.locator("#twk-match-count").innerText(), "6 matches");
    await root.locator("#twk-class-filter").check();
    await page.waitForFunction(() => getComputedStyle(document.querySelector(".secondary")).opacity === "1");
    assert.equal(await buttons.nth(5).evaluate((el) => getComputedStyle(el).opacity), "0.5");

    await page.evaluate(() => {
      const button = document.createElement("button");
      button.className = "chip";
      button.textContent = "Seven";
      document.querySelector("#row-two").append(button);
    });
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#row-two button:last-child")).opacity === "0.5");

    await root.locator('[data-action="toggle-manual"]').click();
    const manual = root.locator("#twk-manual-selector");
    await manual.fill("button.chip");
    assert.match(await root.locator("#twk-manual-feedback").innerText(), /6 elements match/);
    await root.locator('[data-action="apply-manual"]').click();
    assert.equal(await root.locator("#twk-selector").innerText(), "button.chip");
    await manual.fill("button:not(");
    assert.equal(await manual.getAttribute("aria-invalid"), "true");
    await root.locator('[data-action="apply-manual"]').click();
    assert.equal(await root.locator("#twk-selector").innerText(), "button.chip", "invalid selector must not overwrite the rule");
    await manual.fill("#future-element");
    await root.locator('[data-action="apply-manual"]').click();
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).opacity === "1");
    assert.equal(await root.locator("#twk-match-count").innerText(), "0 matches");
    await root.locator('[data-action="select-rule"]').click();
    assert.equal(await root.locator("#twk-specificity").isDisabled(), true, "rules with no matches must still be editable manually");
    await manual.fill("button.chip");
    await root.locator('[data-action="apply-manual"]').click();
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).opacity === "0.5");

    await root.locator("#twk-preset").selectOption("color");
    await root.locator('[data-action="add-property"]').click();
    assert.equal(await root.locator('[data-color-property="color"]').count(), 1);
    await root.locator('[data-property-value="color"]').fill("#33aa77");
    assert.equal(await root.locator('[data-color-property="color"]').inputValue(), "#33aa77");
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(51, 170, 119)");
    const colorPicker = root.locator('[data-color-property="color"]');
    // Playwright's fill on type=color dispatches an untrusted input event; a
    // keyboard adjustment simulates the browser's native, trusted color picker.
    await colorPicker.fill("#1166dd");
    await colorPicker.click();
    await colorPicker.press("ArrowRight");
    const chosen = await colorPicker.inputValue();
    await page.waitForFunction((hex) => {
      const rgb = [1, 3, 5].map((index) => parseInt(hex.slice(index, index + 2), 16));
      return getComputedStyle(document.querySelector("button.chip")).color === `rgb(${rgb.join(", ")})`;
    }, chosen);
    assert.equal(await root.locator('[data-property-value="color"]').inputValue(), chosen);
    await root.locator('[data-property-value="color"]').fill("#33aa77");
    await root.locator("#twk-preset").selectOption("custom");
    await root.locator("#twk-custom-name").fill("border-color");
    await root.locator('[data-action="add-property"]').click();
    assert.equal(await root.locator('[data-color-property="border-color"]').count(), 1, "custom color properties should also get a picker");
    await root.locator('[data-property-value="border-color"]').fill("#8844ff");
    assert.equal(await root.locator('[data-color-property="border-color"]').inputValue(), "#8844ff");
    await root.locator('[data-range-property="opacity"]').click({ position: { x: 110, y: 6 } });
    assert.notEqual(await root.locator('[data-property-value="opacity"]').inputValue(), "0.5", "opacity slider should update the CSS value");

    await root.locator('[data-scope="section"]').click();
    assert.equal(await root.locator("#twk-section-path").inputValue(), "/watch");
    await page.waitForFunction(() => document.querySelector("#tweaklet-editor-root")?.shadowRoot?.getElementById("twk-status")?.textContent === "All changes saved");
    if (process.env.TWEAKLET_SCREENSHOT) await page.screenshot({ path: process.env.TWEAKLET_SCREENSHOT });
    await page.goto(`${base}/watch/second`);
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(51, 170, 119)");
    await page.goto(`${base}/watchlist`);
    assert.equal(await page.locator("button.chip").first().evaluate((el) => getComputedStyle(el).color), "rgb(30, 40, 50)", "/watch should not match /watchlist");
    await page.goto(`${base}/other`);
    assert.equal(await page.locator("button.chip").first().evaluate((el) => getComputedStyle(el).color), "rgb(30, 40, 50)");
    await page.goto(`${base}/watch/first`);
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(51, 170, 119)");

    await send("TWEAKLET_START_PICKING");
    await page.locator("button.chip").first().click();
    await root.locator("#twk-section-path").fill("/guide");
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(30, 40, 50)");
    await page.goto(`${base}/guide/start`);
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(51, 170, 119)");
    await page.goto(`${base}/guidebook`);
    assert.equal(await page.locator("button.chip").first().evaluate((el) => getComputedStyle(el).color), "rgb(30, 40, 50)");
    await page.goto(`${base}/guide/start`);
    await page.waitForFunction(() => getComputedStyle(document.querySelector("button.chip")).color === "rgb(51, 170, 119)");

    // Manual selector targeting also works without clicking a page element first.
    await send("TWEAKLET_CLEAR_SITE");
    await send("TWEAKLET_START_PICKING");
    await root.locator('[data-action="manual-new"]').click();
    const firstSelector = root.locator("#twk-manual-selector");
    await firstSelector.fill("#row-two button");
    await root.locator('[data-action="apply-manual"]').click();
    await root.locator("#twk-preset").selectOption("font-size");
    await root.locator('[data-action="add-property"]').click();
    await root.locator('[data-property-value="font-size"]').fill("20px");
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#row-two button")).fontSize === "20px");
    assert.equal(await root.locator("#twk-count").innerText(), "1");
    assert.notEqual(await page.locator("#row-one button").first().evaluate((el) => getComputedStyle(el).fontSize), "20px");

    // An old v1 rule must keep working without deleting or migrating user data.
    await send("TWEAKLET_CLEAR_SITE");
    await popup.evaluate(() => chrome.storage.local.set({ "tweaklet:site:v1:127.0.0.1": {
      paused: false, rules: [{ id: "legacy", selector: "#row-one", label: "old v1 edit", scope: "site",
        pathname: "/", x: 9, y: 0, props: { "background-color": "#ff0000" } }]
    } }));
    await page.reload();
    await page.waitForFunction(() => document.querySelector("#row-one")?.style.translate !== "");
    assert.match(await page.locator("#row-one").evaluate((el) => el.style.translate), /^9px(?: 0px)?$/);
    assert.equal(await page.locator("#row-one").evaluate((el) => getComputedStyle(el).backgroundColor), "rgb(255, 0, 0)");
    console.log(`PASS: shortcut registered${keyboardWorked ? " and activated" : " (headless activation unavailable)"}, broad matching, class filter, manual selector, color & opacity controls, URL section boundaries, legacy rules`);
  } finally {
    await context.close();
  }
})().catch((error) => { console.error(error); process.exitCode = 1; })
  .finally(() => { server.close(); fs.rmSync(profile, { recursive: true, force: true }); });
