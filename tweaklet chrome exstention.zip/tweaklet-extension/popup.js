(() => {
  "use strict";

  let tabId = null;
  let state = null;
  let busy = false;
  const $ = (id) => document.getElementById(id);

  function message(type, extra = {}) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { type: `TWEAKLET_${type}`, ...extra }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else if (!response || response.error) reject(new Error(response?.error || "No response from this page"));
        else resolve(response);
      });
    });
  }

  function render() {
    if (!state) return;
    $("hostname").textContent = state.hostname;
    $("hostname").title = state.hostname;
    $("site-state").textContent = state.paused ? "Changes paused" : "Changes active";
    $("site-card").classList.toggle("is-paused", state.paused);
    $("pause").setAttribute("aria-checked", String(!state.paused));
    $("pause").title = state.paused ? "Resume saved changes" : "Pause saved changes";
    $("pause").disabled = busy;
    $("edit").disabled = busy || state.paused;
    $("edit-label").textContent = state.editing ? "Finish editing" : "Start editing this page";
    $("edit-hint").textContent = state.paused
      ? "Resume changes above to edit this website."
      : state.editing
        ? "Your edits save automatically as you make them."
        : "Click an element, then drag it or adjust its properties.";
    const count = state.ruleCount;
    $("saved-count").textContent = `${count} saved ${count === 1 ? "edit" : "edits"}`;
    $("reset").hidden = count === 0;
    $("reset").disabled = busy;
  }

  function showError(text) {
    $("error").textContent = text;
    $("error").hidden = false;
  }

  async function perform(operation) {
    if (busy) return;
    busy = true;
    $("error").hidden = true;
    render();
    try {
      state = await operation();
      render();
    } catch (error) {
      showError(error.message || "Something went wrong. Reload the page and try again.");
    } finally {
      busy = false;
      render();
    }
  }

  $("pause").addEventListener("click", () => perform(() => message("SET_PAUSED", { paused: !state.paused })));
  $("edit").addEventListener("click", () => perform(() => message("SET_EDITOR", { enabled: !state.editing })));
  $("reset").addEventListener("click", () => {
    if (window.confirm(`Remove all ${state.ruleCount} saved edits on ${state.hostname}? This can't be undone.`)) {
      perform(() => message("CLEAR_SITE"));
    }
  });
  $("shortcut-edit").addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));
  chrome.commands.getAll((commands) => {
    const shortcut = commands?.find((item) => item.name === "pick-element")?.shortcut;
    $("shortcut-key").textContent = shortcut || "Not set";
    $("shortcut-key").title = shortcut || "Choose a shortcut in Chrome";
  });

  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const error = chrome.runtime.lastError;
    if (error || !tabs?.[0]?.id) {
      $("supported").hidden = true;
      $("unsupported").hidden = false;
      return;
    }
    tabId = tabs[0].id;
    try {
      state = await message("GET_STATUS");
      render();
    } catch {
      $("supported").hidden = true;
      $("unsupported").hidden = false;
    }
  });
})();
