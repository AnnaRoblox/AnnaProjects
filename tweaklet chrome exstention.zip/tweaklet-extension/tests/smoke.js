/* Optional integration smoke test: npm install --no-save playwright && npx playwright install chromium && node tests/smoke.js */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require("playwright");

const extensionPath = path.resolve(__dirname, "..");
const profile = fs.mkdtempSync(path.join(os.tmpdir(), "tweaklet-smoke-"));
const server = http.createServer((request, response) => {
  response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'none'; style-src 'self'; style-src-attr 'none'");
  if (request.url === "/site.css") {
    response.setHeader("Content-Type", "text/css");
    response.end("body{margin:0;background:#f7f5ff;font:16px Arial}main{padding:120px 100px}#hero{width:310px;height:110px;background:#dce4fb;color:#203157;border-radius:12px;padding:20px;box-sizing:border-box}#other{margin-top:35px}");
  } else {
    response.setHeader("Content-Type", "text/html");
    response.end('<!doctype html><html><head><link rel="stylesheet" href="/site.css"></head><body><main><div id="hero">Move and restyle me</div><button id="other">Another button</button></main></body></html>');
  }
});

(async () => {
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const context = await chromium.launchPersistentContext(profile, {
    channel: "chromium", headless: true, viewport: { width: 1220, height: 820 },
    args: [`--disable-extensions-except=${extensionPath}`, `--load-extension=${extensionPath}`]
  });
  try {
    const extensions = await context.newPage();
    await extensions.goto("chrome://extensions");
    const id = await extensions.locator("extensions-item").first().getAttribute("id");
    assert.match(id, /^[a-p]{32}$/);
    const page = await context.newPage();
    page.on("console", (msg) => { if (msg.type() === "error") console.log("site console:", msg.text()); });
    await page.goto(`${base}/home`);
    const popup = await context.newPage();
    await popup.goto(`chrome-extension://${id}/popup.html`);
    await page.bringToFront();
    await popup.reload();
    await popup.waitForFunction(() => document.querySelector("#hostname")?.textContent === "127.0.0.1");
    assert.match(await popup.locator("#saved-count").innerText(), /0 saved edits/);
    await popup.evaluate(() => document.getElementById("edit").click());
    const root = page.locator("#tweaklet-editor-root");
    await root.waitFor();
    assert.equal(await root.locator("#twk-empty-title").innerText(), "Choose something to change");
    const panelBg = await root.locator("#twk-panel").evaluate((el) => getComputedStyle(el).backgroundColor);
    assert.equal(panelBg, "rgb(255, 255, 255)", "editor styling should survive a strict site CSP");

    await page.locator("#hero").click({ position: { x: 90, y: 60 } });
    await root.locator("#twk-target-name").waitFor({ state: "visible" });
    assert.equal(await root.locator("#twk-target-name").innerText(), "div#hero");
    await root.locator("#twk-preset").selectOption("background-color");
    await root.locator('[data-action="add-property"]').click();
    await root.locator('[data-property-value="background-color"]').fill("#ff0000");
    await root.locator("#twk-x").fill("60");
    await root.locator("#twk-y").fill("25");
    await root.locator("#twk-status").waitFor({ state: "visible" });
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "60px 25px");
    await page.waitForFunction(() => document.querySelector("#hero") && getComputedStyle(document.querySelector("#hero")).backgroundColor === "rgb(255, 0, 0)");
    await page.waitForFunction(() => document.querySelector("#tweaklet-editor-root")?.shadowRoot?.getElementById("twk-status")?.textContent === "All changes saved");
    assert.equal(await popup.evaluate(() => new Promise((resolve) => chrome.storage.local.get(null, resolve)).then((all) => Object.values(all)[0]?.rules?.length)), 1);

    // An existing edit can be moved by dragging the handle, not just by typing offsets.
    const handle = await root.locator("#twk-handle").boundingBox();
    await page.mouse.move(handle.x + 30, handle.y + 12);
    await page.mouse.down();
    await page.mouse.move(handle.x + 60, handle.y + 42, { steps: 5 });
    await page.mouse.up();
    assert.equal(await root.locator("#twk-x").inputValue(), "90");
    assert.equal(await root.locator("#twk-y").inputValue(), "55");
    await page.waitForFunction(() => document.querySelector("#tweaklet-editor-root")?.shadowRoot?.getElementById("twk-status")?.textContent === "All changes saved");

    await root.locator('[data-action="close"]').click();
    await page.reload();
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "90px 55px");
    assert.equal(await page.locator("#hero").evaluate((el) => getComputedStyle(el).backgroundColor), "rgb(255, 0, 0)");

    async function command(type, extra = {}) {
      await page.bringToFront();
      return popup.evaluate(({ type, extra }) => new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.tabs.sendMessage(tabs[0].id, { type, ...extra }, (response) => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(response);
          });
        });
      }), { type, extra });
    }

    assert.equal((await command("TWEAKLET_GET_STATUS")).ruleCount, 1);
    await command("TWEAKLET_SET_EDITOR", { enabled: true });
    await page.locator("#hero").click({ position: { x: 20, y: 20 } });
    await root.locator('[data-scope="page"]').click();
    await page.waitForFunction(() => document.querySelector("#tweaklet-editor-root")?.shadowRoot?.getElementById("twk-status")?.textContent === "All changes saved");
    await page.goto(`${base}/another-path`);
    assert.equal(await page.locator("#hero").evaluate((el) => getComputedStyle(el).backgroundColor), "rgb(220, 228, 251)", "a page-only edit must not leak to another URL");
    assert.equal(await page.locator("#hero").evaluate((el) => el.style.translate), "");
    await page.goto(`${base}/home`);
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "90px 55px");
    await page.evaluate(() => history.pushState({}, "", "/another-path"));
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "");
    await page.evaluate(() => history.pushState({}, "", "/home"));
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "90px 55px");

    // Test the actual popup toggle, rather than only calling the content-script API.
    await page.bringToFront();
    await popup.reload();
    await popup.waitForFunction(() => document.querySelector("#saved-count")?.textContent === "1 saved edit");
    await popup.evaluate(() => document.getElementById("pause").click());
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#hero")).backgroundColor === "rgb(220, 228, 251)");
    await popup.waitForFunction(() => document.querySelector("#site-state")?.textContent === "Changes paused");
    await popup.evaluate(() => document.getElementById("pause").click());
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#hero")).backgroundColor === "rgb(255, 0, 0)");
    await page.evaluate(() => {
      const replacement = document.createElement("div");
      replacement.id = "hero";
      replacement.textContent = "New dynamic element";
      document.querySelector("#hero").replaceWith(replacement);
    });
    await page.waitForFunction(() => document.querySelector("#hero")?.style.translate === "90px 55px");
    assert.equal(await page.locator("#hero").evaluate((el) => getComputedStyle(el).backgroundColor), "rgb(255, 0, 0)");
    assert.equal((await command("TWEAKLET_CLEAR_SITE")).ruleCount, 0);
    assert.equal(await page.locator("#hero").evaluate((el) => el.style.translate), "");

    await command("TWEAKLET_SET_EDITOR", { enabled: true });
    await page.locator("#other").click();
    await root.locator("#twk-preset").selectOption("custom");
    await root.locator("#twk-custom-name").fill("letter-spacing");
    await root.locator('[data-action="add-property"]').click();
    await root.locator('[data-property-value="letter-spacing"]').fill("3px");
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#other")).letterSpacing === "3px");
    await root.locator('[data-action="delete-rule"]').click();
    await page.waitForFunction(() => getComputedStyle(document.querySelector("#other")).letterSpacing === "normal");
    console.log("PASS: popup, selection, CSS & custom edits, drag, persistence, page & SPA scope, pause, dynamic content, reset, strict CSP");
  } finally {
    await context.close();
  }
})().catch((error) => { console.error(error); process.exitCode = 1; })
  .finally(() => { server.close(); fs.rmSync(profile, { recursive: true, force: true }); });
